package cn.laoya.capture.pro;
import org.json.*;import java.util.*;
public final class DevData {
 public static JSONArray jobs()throws Exception{JSONArray a=new JSONArray();for(DevJobs.Job j:DevJobs.list())a.put(job(j,false));return a;}
 public static JSONObject job(DevJobs.Job j,boolean full)throws Exception{
  List<DevJobs.Row> rows=j.snapshot();int pass=0,errors=0;ArrayList<Long> times=new ArrayList<>();for(DevJobs.Row r:rows){if(r.pass)pass++;if(!r.error.isEmpty())errors++;times.add(r.ms);}Collections.sort(times);long sum=0;for(long t:times)sum+=t;
  JSONObject out=new JSONObject().put("id",j.id).put("type",j.type).put("state",j.state).put("start",j.start).put("end",j.end).put("total",j.total).put("done",rows.size()).put("pass",pass).put("errors",errors).put("error",j.error).put("average",times.isEmpty()?0:sum/times.size()).put("p50",pct(times,.5)).put("p95",pct(times,.95)).put("p99",pct(times,.99));
  if(full){JSONArray a=new JSONArray();rows.sort(Comparator.comparingInt(r->r.index));for(DevJobs.Row r:rows)a.put(new JSONObject().put("index",r.index).put("attempt",r.attempt).put("status",r.status).put("ms",r.ms).put("flowId",r.flowId).put("pass",r.pass).put("error",r.error).put("url",r.url).put("title",r.title).put("description",r.description).put("contentType",r.contentType).put("depth",r.depth).put("links",r.links).put("textLength",r.text.length()));out.put("rows",a);}return out;
 }
 static long pct(List<Long> a,double p){return a.isEmpty()?0:a.get(Math.max(0,(int)Math.ceil(a.size()*p)-1));}
}
