package cn.laoya.wechatmonitor;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    private volatile boolean checking=false;
    @Override public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,16,29));getWindow().setNavigationBarColor(Color.rgb(8,16,29));
        web=new WebView(this);web.setBackgroundColor(Color.rgb(8,16,29));
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(false);
        settings.setAllowContentAccess(false);settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(),"DuckNative");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                Uri url=request.getUrl();
                if("file".equals(url.getScheme())&&"/android_asset/index.html".equals(url.getPath()))return false;
                if("https".equals(url.getScheme())){openLink(url.toString());}
                return true;
            }
            @Override public void onPageFinished(WebView view,String url){web.evaluateJavascript("if(window.refreshData)refreshData()",null);}
        });
        setContentView(web);web.loadUrl("file:///android_asset/index.html");
        MonitorJobService.schedule(this);
    }
    private void emit(String message){runOnUiThread(()->web.evaluateJavascript("window.onNativeUpdate && window.onNativeUpdate("+org.json.JSONObject.quote(message)+")",null));}
    private void openLink(String url){try{
        Uri parsed=Uri.parse(url);if(!"https".equalsIgnoreCase(parsed.getScheme()))return;
        startActivity(new Intent(Intent.ACTION_VIEW,parsed));
    }catch(Exception e){Toast.makeText(this,"无法打开文章链接",Toast.LENGTH_SHORT).show();}}
    private class Bridge {
        @JavascriptInterface public String getData(){Store s=new Store(MainActivity.this);try{return s.snapshot();}finally{s.close();}}
        @JavascriptInterface public int addAccount(String name,String id){Store s=new Store(MainActivity.this);try{return s.addPublisher(name,id);}finally{s.close();}}
        @JavascriptInterface public int importBatch(String raw){Store s=new Store(MainActivity.this);try{return s.importBatch(raw);}finally{s.close();}}
        @JavascriptInterface public void deleteAccount(int id){Store s=new Store(MainActivity.this);try{s.deletePublisher(id);}finally{s.close();}}
        @JavascriptInterface public void toggleAccount(int id){Store s=new Store(MainActivity.this);try{s.togglePublisher(id);}finally{s.close();}}
        @JavascriptInterface public int addArticle(int accountId,String title,String url,String publishedAt){Store s=new Store(MainActivity.this);try{return s.addArticle(accountId,title,url,publishedAt);}finally{s.close();}}
        @JavascriptInterface public String saveEndpoint(String endpoint){Store s=new Store(MainActivity.this);try{s.setSetting("feed_template",endpoint);return "设置已保存";}catch(Exception e){return "保存失败："+e.getMessage();}finally{s.close();}}
        @JavascriptInterface public void openArticle(String url){runOnUiThread(()->openLink(url));}
        @JavascriptInterface public void syncNow(){
            synchronized(MainActivity.this){if(checking){emit("已有检测任务正在执行");return;}checking=true;}
            emit("开始检测公众号...");
            new Thread(()->{String result;
                try{result=MonitorEngine.run(getApplicationContext(),true,MainActivity.this::emit);}
                catch(Exception e){result="检查失败："+e.getMessage();}
                synchronized(MainActivity.this){checking=false;}emit(result);
            },"wechat-manual-sync").start();
        }
        @JavascriptInterface public void exportData(){
            Store s=new Store(MainActivity.this);String payload;try{payload=s.snapshot();}finally{s.close();}
            runOnUiThread(()->{
                try {Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/json");send.putExtra(Intent.EXTRA_TEXT,payload);startActivity(Intent.createChooser(send,"导出监控数据"));}
                catch(Exception e){Toast.makeText(MainActivity.this,"未找到分享应用",Toast.LENGTH_SHORT).show();}
            });
        }
    }
    @Override public void onBackPressed(){web.evaluateJavascript("window.backToHome&&window.backToHome()",null);}
    @Override public void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
