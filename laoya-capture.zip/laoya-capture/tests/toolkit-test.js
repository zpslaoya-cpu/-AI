'use strict';
const assert=require('node:assert/strict'),kit=require('../app/src/main/assets/toolkit.js');
(async()=>{
 assert.equal(kit.tools.length,100);
 for(const tool of kit.tools){let result;try{result=await kit.run(tool.id,tool.sample,tool.second,tool.options);}catch(e){throw Error(tool.id+': '+e.stack);}assert.deepEqual(JSON.parse(JSON.stringify(result.value)),tool.expected,'sample result '+tool.id);}
 assert.deepEqual(kit.helpers.csv('a,b\r\n"x\ny","a""b"'),[['a','b'],['x\ny','a"b']]);
 await assert.rejects(()=>kit.run('csv.parse','"not closed'),/未闭合/);
 await assert.rejects(()=>kit.run('csv.objects','a,a\n1,2'),/表头重复/);
 await assert.rejects(()=>kit.run('http.headersRaw','{"x":"bad\\r\\ninjected: y"}'),/头值/);
 await assert.rejects(()=>kit.run('json.pointer','{"a":[1]}','/a/01'),/索引/);
 await assert.rejects(()=>kit.run('json.pointer','{}','/a~2b'),/转义/);
 await assert.rejects(()=>kit.run('ip.maskCidr','255.0.255.0'),/连续/);
 await assert.rejects(()=>kit.run('json.keys','{\"id\":9007199254740993}'),/安全范围/);
 const tiny=await kit.run('ip.subnet','192.0.2.1/32');assert.equal(tiny.value.usable,1);assert.equal(tiny.value.first,'192.0.2.1');
 const all=await kit.run('ip.subnet','0.0.0.0/0');assert.equal(all.value.addresses,4294967296);
 const proto=await kit.run('json.mergePatch','{}','{"__proto__":{"polluted":true}}');assert.equal(Object.getPrototypeOf(proto.value),null);assert.equal({}.polluted,undefined);
 await assert.rejects(()=>kit.run('number.range','1','100000'),/10000/);
 await assert.rejects(()=>kit.run('text.stats','a'.repeat(262145)),/256Ki/);
 assert.equal((await kit.run('number.bases','9007199254740993')).value.decimal,'9007199254740993');
 assert.match((await kit.run('csv.write','[{"x":"=HYPERLINK(1)"}]')).text,/'=HYPERLINK/);
 console.log('PASS: all 100 tools have checked sample outputs; CSV quoting/formula guard, header injection rejection, pointer errors/prototype safety, IPv4 boundaries, exact BigInt, size bounds');
})().catch(e=>{console.error(e);process.exitCode=1;});
