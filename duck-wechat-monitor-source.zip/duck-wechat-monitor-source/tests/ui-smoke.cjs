const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'),'utf8');
const script = source.match(/<script>([\s\S]*?)<\/script>/i)?.[1];
assert(script,'HTML must contain main script');
new vm.Script(script,{filename:'index.html inline JS'});
const widgets = new Map();
function elem(id) {
  if (!widgets.has(id))widgets.set(id,{
    innerHTML:'',textContent:'',value:'',
    classList:{toggle(){}},
  });
  return widgets.get(id);
}
const fakeData={publishers:[{id:1,name:'测试公众号',original_id:'gh_123',enabled:true,last_check:0,status:'未检测',last_error:'',count:1}],articles:[{id:1,publisher_id:1,publisher:'测试公众号',title:'重大新闻',url:'https://mp.weixin.qq.com/s?__biz=x&mid=1&idx=1',published_at:'2026-10-24',discovered_at:1792800000000}],runs:[],feed_template:''};
const ctx={
  DuckNative:{getData:()=>JSON.stringify(fakeData),importBatch:()=>1,openArticle:()=>{},saveEndpoint:()=> '设置已保存',syncNow:()=>{}},
  document:{getElementById:elem},
  window:{addEventListener(){},scrollTo(){}},
  alert() {},confirm:()=>true,
  console,Date,JSON,Number,String,
};
vm.createContext(ctx);
vm.runInContext(script,ctx);
ctx.refreshData();
assert.equal(elem('statAccounts').textContent,1);
assert.equal(elem('statArticles').textContent,1);
assert(elem('recentArticles').innerHTML.includes('重大新闻'));
ctx.switchTab('archive');
assert.equal(elem('archiveCount').textContent,'1 篇');
elem('search').value='找不到的关键词';ctx.renderArchive();
assert.equal(elem('archiveCount').textContent,'0 篇');
ctx.resetFilters();
assert.equal(elem('archiveCount').textContent,'1 篇');
console.log('PASS: UI parsing, state rendering, article filtering, archive tabs');
