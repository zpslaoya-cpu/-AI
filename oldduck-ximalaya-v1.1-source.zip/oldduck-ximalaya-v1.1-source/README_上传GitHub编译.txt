🦆 老鸭喜马拉雅 Android V1.1

1. 将本压缩包的 .github/ 和 android-ximalaya/ 这两个文件夹上传到你有写权限的 GitHub 仓库根目录。
2. 进入仓库 Actions → Build OldDuck Ximalaya Android V1.1 APK → Run workflow。
3. 编译成功后进入对应工作流的 Artifacts，下载 oldduck-ximalaya-v1-1-apk。
4. 解压得到 ZIP，再解压 ZIP 中的老鸭喜马拉雅_V1.1.apk，用安卓手机安装。

注意：本工程仅具备账号管理、旧账户 JSON 导入、加密保管、统计和日志等本地功能，尚未接通真实金币/提现接口。编译尚未在本环境实测。
