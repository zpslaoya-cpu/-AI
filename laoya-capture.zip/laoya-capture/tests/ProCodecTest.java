package cn.laoya.capture.pro;
import java.nio.file.*;import java.nio.charset.*;import java.io.*;import java.util.zip.*;
public class ProCodecTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception{
  Model.directory=Files.createTempDirectory("codec").toFile();String text="<html>中文正文</html>";
  for(String encoding:new String[]{"gzip","zlib","raw"}){
   ByteArrayOutputStream bytes=new ByteArrayOutputStream();OutputStream z=encoding.equals("gzip")?new GZIPOutputStream(bytes):new DeflaterOutputStream(bytes,new Deflater(6,encoding.equals("raw")));z.write(text.getBytes(StandardCharsets.UTF_8));z.close();Model.Message m=new Model.Message();m.set("Content-Type","text/html; charset=utf-8");m.set("Content-Encoding",encoding.equals("gzip")?"gzip":"deflate");m.bytes(bytes.toByteArray());check(text.equals(Codec.text(m,"")),encoding+" decode");try{Codec.decoded(m,2);throw new AssertionError("bound missing");}catch(IOException expected){}
  }
  Model.Message m=new Model.Message();m.set("Content-Type","text/html");m.bytes("\ufeff中文".getBytes(StandardCharsets.UTF_16LE));check("中文".equals(Codec.text(m,"")),"BOM");Codec.edit(m,"改后","Content-Encoding: gzip\nContent-Length: 99\nContent-Type: text/plain","HTTP/1.1 202 Accepted");check(m.header("Content-Encoding").isEmpty()&&m.header("Content-Length").isEmpty(),"framing reset");check(m.size==6,"UTF8 bytes");try{Codec.edit(m,"x","X: a\rb","HTTP/1.1 200 OK");throw new AssertionError("CR accepted");}catch(IOException expected){}
  System.out.println("PASS: gzip, zlib/raw deflate, UTF16 BOM, UTF8 byte length, decoding bounds, header injection rejection");
 }
}
