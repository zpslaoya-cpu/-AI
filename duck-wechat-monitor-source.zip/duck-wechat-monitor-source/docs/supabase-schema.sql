-- Duck WeChat Monitor v1 | Supabase PostgreSQL 15+
-- First-run schema for an EMPTY project. Run in Supabase SQL Editor after review.
-- Assumes Supabase Auth is enabled. Do not add a public write path for ingestion.

create extension if not exists pgcrypto with schema extensions;
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

-- Public, non-sensitive directory metadata. An account is not a subscriber.
create table if not exists public.wechat_accounts (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) between 1 and 160),
  original_id text,
  wechat_handle text,
  avatar_url text,
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists wechat_accounts_original_id_uq
  on public.wechat_accounts(original_id) where original_id is not null;
create index if not exists wechat_accounts_name_idx on public.wechat_accounts(name);

-- One monitored account can be followed by many authenticated users.
create table if not exists public.wechat_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  account_id uuid not null references public.wechat_accounts(id) on delete cascade,
  enabled boolean not null default true,
  notify_enabled boolean not null default true,
  tags text[] not null default '{}',
  created_at timestamptz not null default now(),
  unique (user_id, account_id)
);
create index if not exists wechat_subscriptions_account_idx
  on public.wechat_subscriptions(account_id) where enabled;

-- Dedup uses stable article_key derived by ingestion worker:
-- 'wechat:<biz>:<mid>:<idx>' > 'provider:<id>' > 'url:<sha256(normalized-url)>'
-- Do not use title alone to deduplicate.
create table if not exists public.wechat_articles (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references public.wechat_accounts(id) on delete cascade,
  article_key text not null,
  title text not null check (length(btrim(title)) between 1 and 1000),
  original_url text not null,
  canonical_url text not null,
  cover_url text,
  summary text,
  provider_article_id text,
  biz text,
  mid text,
  article_idx integer check (article_idx is null or article_idx >= 0),
  published_at timestamptz,
  published_on date,               -- China local publication date if known
  detected_at timestamptz not null default now(),
  detected_on date not null default ((now() at time zone 'Asia/Shanghai')::date),
  last_seen_at timestamptz not null default now(),
  availability text not null default 'available'
    check (availability in ('available','unavailable','unknown')),
  ingestion_source text not null check (ingestion_source in ('authorized_api','licensed_feed','manual')),
  metadata jsonb not null default '{}'::jsonb,
  unique (account_id, article_key),
  constraint publication_pair_check check
    ((published_at is null and published_on is null)
      or (published_at is not null and published_on is not null))
);
create index if not exists wechat_articles_by_date_idx
  on public.wechat_articles(published_on desc, detected_at desc);
create index if not exists wechat_articles_by_account_date_idx
  on public.wechat_articles(account_id, published_on desc, detected_at desc);
create index if not exists wechat_articles_by_first_seen_idx
  on public.wechat_articles(detected_on desc, detected_at desc);

-- Each user gets one in-app notification per newly found article.
create table if not exists public.wechat_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  article_id uuid not null references public.wechat_articles(id) on delete cascade,
  created_at timestamptz not null default now(),
  read_at timestamptz,
  unique (user_id, article_id)
);
create index if not exists wechat_notifications_unread_idx
  on public.wechat_notifications(user_id, created_at desc) where read_at is null;

-- User-visible monitoring health (no API keys/endpoints).
create table if not exists public.wechat_monitor_status (
  account_id uuid primary key references public.wechat_accounts(id) on delete cascade,
  health text not null default 'not_configured'
    check (health in ('not_configured','ok','delayed','failed','paused')),
  last_attempt_at timestamptz,
  last_success_at timestamptz,
  last_new_article_at timestamptz,
  last_error_code text,
  updated_at timestamptz not null default now()
);

-- Internal sources: access only from trusted server/Edge Functions.
-- Provider secrets belong in Supabase Vault or Edge Function secrets, NOT here.
create table if not exists private.wechat_sources (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references public.wechat_accounts(id) on delete cascade,
  source_type text not null check (source_type in ('authorized_api','licensed_feed')),
  source_endpoint text,             -- controlled by server-side admins; never arbitrary user input
  secret_alias text,                -- identifier only, never the credential
  enabled boolean not null default false,
  poll_interval_minutes integer not null default 120
    check (poll_interval_minutes between 15 and 1440),
  next_check_at timestamptz not null default now(),
  leased_until timestamptz,
  failure_count integer not null default 0,
  updated_at timestamptz not null default now(),
  unique (account_id)
);
create index if not exists wechat_sources_due_idx
  on private.wechat_sources(next_check_at) where enabled;

-- A failed run is recorded separately and MUST NOT claim 'no new articles'.
create table if not exists private.wechat_fetch_runs (
  id uuid primary key default gen_random_uuid(),
  source_id uuid not null references private.wechat_sources(id) on delete cascade,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  status text not null default 'running'
    check (status in ('running','success','partial','failed','rate_limited')),
  fetched_count integer not null default 0 check (fetched_count >= 0),
  new_count integer not null default 0 check (new_count >= 0),
  updated_count integer not null default 0 check (updated_count >= 0),
  error_code text,
  error_detail text
);
create index if not exists wechat_fetch_runs_source_idx
  on private.wechat_fetch_runs(source_id, started_at desc);

-- Security: never permit anonymous write access.
alter table public.wechat_accounts enable row level security;
alter table public.wechat_subscriptions enable row level security;
alter table public.wechat_articles enable row level security;
alter table public.wechat_notifications enable row level security;
alter table public.wechat_monitor_status enable row level security;
alter table private.wechat_sources enable row level security;
alter table private.wechat_fetch_runs enable row level security;

revoke all on public.wechat_accounts from anon, authenticated;
revoke all on public.wechat_subscriptions from anon, authenticated;
revoke all on public.wechat_articles from anon, authenticated;
revoke all on public.wechat_notifications from anon, authenticated;
revoke all on public.wechat_monitor_status from anon, authenticated;
revoke all on private.wechat_sources from anon, authenticated;
revoke all on private.wechat_fetch_runs from anon, authenticated;

grant select on public.wechat_accounts to authenticated;
grant select, insert, delete on public.wechat_subscriptions to authenticated;
grant update (enabled, notify_enabled, tags) on public.wechat_subscriptions to authenticated;
grant select on public.wechat_articles to authenticated;
grant select on public.wechat_monitor_status to authenticated;
grant select on public.wechat_notifications to authenticated;
grant update (read_at) on public.wechat_notifications to authenticated;

create policy "read account directory" on public.wechat_accounts
  for select to authenticated using (true);
create policy "read own subscriptions" on public.wechat_subscriptions
  for select to authenticated using (user_id = (select auth.uid()));
create policy "subscribe to account" on public.wechat_subscriptions
  for insert to authenticated with check (user_id = (select auth.uid()));
create policy "update own subscription" on public.wechat_subscriptions
  for update to authenticated using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));
create policy "unsubscribe from account" on public.wechat_subscriptions
  for delete to authenticated using (user_id = (select auth.uid()));
create policy "read subscribed articles" on public.wechat_articles
  for select to authenticated using (
    exists (select 1 from public.wechat_subscriptions s
      where s.account_id = wechat_articles.account_id
        and s.user_id = (select auth.uid()) and s.enabled)
  );
create policy "read subscribed monitor status" on public.wechat_monitor_status
  for select to authenticated using (
    exists (select 1 from public.wechat_subscriptions s
      where s.account_id = wechat_monitor_status.account_id
        and s.user_id = (select auth.uid()) and s.enabled)
  );
create policy "read own notifications" on public.wechat_notifications
  for select to authenticated using (user_id = (select auth.uid()));
create policy "mark own notifications read" on public.wechat_notifications
  for update to authenticated using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- Date archive accessible only within the caller's subscription visibility.
create or replace view public.wechat_daily_archive
with (security_invoker = true) as
select s.user_id,
       coalesce(a.published_on, a.detected_on) as archive_date,
       case when a.published_on is null then 'first_detected' else 'published' end as date_basis,
       count(*)::bigint as article_count,
       count(distinct a.account_id)::bigint as account_count
from public.wechat_subscriptions s
join public.wechat_articles a on a.account_id = s.account_id
where s.enabled
 group by s.user_id, coalesce(a.published_on, a.detected_on),
          case when a.published_on is null then 'first_detected' else 'published' end;
revoke all on public.wechat_daily_archive from anon, authenticated;
grant select on public.wechat_daily_archive to authenticated;

-- Helpful action: single privileged ingest transaction should INSERT ... ON CONFLICT
-- (account_id, article_key) DO UPDATE SET last_seen_at = now(), ...
-- Create notifications ONLY for newly inserted articles, never on every poll.
-- Validation and normalization MUST happen in the trusted ingestion function.
