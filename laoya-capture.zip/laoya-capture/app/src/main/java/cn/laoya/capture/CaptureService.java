package cn.laoya.capture;
import android.app.*;import android.content.*;import android.net.*;import android.os.*;import java.io.*;import cn.laoya.capture.pro.*;
public class CaptureService extends VpnService {
 private ParcelFileDescriptor vpn;private Engine proxy;private static volatile Engine active;
 public static Model.Flow replay(Model.Message m)throws Exception{Engine p=active;if(p==null||!Model.running)throw new IOException("请先启动监听");return p.replay(m);}
 @Override public int onStartCommand(Intent i,int flags,int id){if(i==null||"STOP".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}if(Model.running)return START_NOT_STICKY;
  getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("capture","本地HTTP调试",NotificationManager.IMPORTANCE_LOW));PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);PendingIntent open=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
  startForeground(1,new Notification.Builder(this,"capture").setContentTitle("老鸭抓包 CYBER PRO").setContentText("本地代理监听 / 点击打开 / 可停止").setSmallIcon(android.R.drawable.stat_sys_upload).setContentIntent(open).addAction(new Notification.Action.Builder(null,"停止",stop).build()).build());
  try{String pkg=i.getStringExtra("package");if(pkg==null||pkg.isEmpty())pkg=getSharedPreferences("pro",0).getString("package","");if(pkg.isEmpty())throw new IOException("请先选择APP");Model.directory=new File(getFilesDir(),"bodies");Model.directory.mkdirs();proxy=new Engine(s->protect(s),new Rules());proxy.start();vpn=new Builder().setSession("老鸭抓包 CYBER PRO").addAddress("10.77.0.1",32).addAllowedApplication(pkg).setHttpProxy(ProxyInfo.buildDirectProxy("127.0.0.1",proxy.port())).establish();if(vpn==null)throw new IOException("VPN授权失效");active=proxy;Model.running=true;Model.state="监听中 · HTTP调试 / HTTPS隧道";
  }catch(Exception e){Model.state="启动失败："+e.getMessage();stopSelf();}return START_NOT_STICKY;}
 @Override public void onRevoke(){stopSelf();}
 @Override public void onDestroy(){active=null;if(proxy!=null)proxy.close();try{if(vpn!=null)vpn.close();}catch(Exception ignored){}Model.running=false;Model.stopBatch=true;Model.releaseAll();Overlay.hide();if(!Model.state.startsWith("启动失败"))Model.state="监听已停止";stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
