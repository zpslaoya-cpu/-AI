package cn.laoya.capture;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
public class CaptureService extends VpnService {
 private ParcelFileDescriptor vpn;
 private LocalProxy proxy;
 private static volatile LocalProxy activeProxy;
 public static void replay(byte[] bytes)throws IOException{LocalProxy p=activeProxy;if(p==null||!Records.running)throw new IOException("请先开始监听");p.replay(bytes);}
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i==null||"STOP".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}
  if(Records.running)return START_NOT_STICKY;
  NotificationManager nm=getSystemService(NotificationManager.class);
  nm.createNotificationChannel(new NotificationChannel("capture","本地抓包",NotificationManager.IMPORTANCE_LOW));
  PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);
  PendingIntent open=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
  startForeground(1,new Notification.Builder(this,"capture").setContentTitle("老鸭抓包 · 代理模式").setContentText("点击返回查看；可随时停止").setSmallIcon(android.R.drawable.stat_sys_upload).setContentIntent(open).addAction(new Notification.Action.Builder(null,"停止",stop).build()).build());
  try {
   String pkg=i.getStringExtra("package");
   if(pkg==null||pkg.isEmpty())throw new IOException("请先选择APP");
   proxy=new LocalProxy(s->protect(s));proxy.start();
   Builder b=new Builder().setSession("老鸭抓包·代理").addAddress("10.77.0.1",32).addAllowedApplication(pkg).setHttpProxy(ProxyInfo.buildDirectProxy("127.0.0.1",proxy.port()));
   // No default route: this is an advisory proxy VPN, not a TCP/IP forwarding engine.
   vpn=b.establish();if(vpn==null)throw new IOException("VPN授权失效");
   activeProxy=proxy;Records.running=true;Records.state="代理运行中：仅兼容遵循系统代理的APP";
  }catch(Exception e){Records.state="启动失败："+e.getMessage();stopSelf();}
  return START_NOT_STICKY;
 }
 @Override public void onRevoke(){stopSelf();}
 @Override public void onDestroy(){activeProxy=null;if(proxy!=null)proxy.close();try{if(vpn!=null)vpn.close();}catch(IOException ignored){}Records.running=false;if(!Records.state.startsWith("启动失败"))Records.state="已停止";stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
