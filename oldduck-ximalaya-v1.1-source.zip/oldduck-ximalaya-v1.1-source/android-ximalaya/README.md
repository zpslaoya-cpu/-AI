# 🦆 老鸭喜马拉雅 Android V1.1（原版数据迁移准备版）

本项目**不是金币自动任务或真实提现完整版**。提供安卓本地账号与收益记录、每日区间统计、TXT 导出，以及从 Windows 原版的 `xmly_accounts.json` 安全导入账号凭据。

## 可用模块

- 安卓 WebView UI、SQLite 本地数据保存，账号/备注编辑与批量导入。
- 手机系统文件选择器读取 Windows 原版 `xmly_accounts.json`，解析 uid / remark / cookie / proxy。凭据使用 Android Keystore AES-GCM 加密，不经过 WebView 明文，不会包含在日志和 TXT 导出中。
- 数据库增量升级，保留已有数据；同一账号同一天可记录多次完成；金币与提现金额独立统计。
- 自定义起止日期、按天汇总、每号逐日明细、导出 TXT、日志查询、群链接。

## 如何导入 Windows 原版账号

1. 从 Windows 电脑上找到自己原版工具目录的 `xmly_accounts.json`。
2. 用 USB 或本地文件传输将文件放到自己的 Android 手机上。**不要将含 Cookie 的文件公开上传到聊天、网盘或仓库。**
3. 在手机端打开 APP → 账号 →「选择 xmly_accounts.json 导入」→ 选择文件。
4. 账号条目会显示“已加密导入凭据”。导出数据时不会包含密钥或 Cookie。

原版 Cookie 可能过期；导入成功不代表登录成功。无法从旧文件取得历史每账号金币收益的，不能伪造数据。

## 尚未实现

- Android 自动登录、金币任务执行、收益查询；真实提现、自动重试、后台运行。
- 需要先验证 `ximalaya_core.cp312-win_amd64.pyd` 所承担的签名与 Ticket 协议，再实现可在 Android 运行的等价模块。

## 编译和测试

JDK 17 + Android SDK 35 + Gradle 8.7：`gradle :app:assembleDebug`；APK 默认路径 `app/build/outputs/apk/debug/app-debug.apk`。

本地：`node tests/report.test.js` 与 `python tests/ui_smoke.py`。当前环境无 Android SDK，未执行 APK 编译或真机测试。

技术调查、剩余任务和注意事项详见：`迁移研究报告_20261027.md`。
