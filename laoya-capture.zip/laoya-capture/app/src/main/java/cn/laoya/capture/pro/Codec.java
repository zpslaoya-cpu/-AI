package cn.laoya.capture.pro;
import java.io.*;import java.nio.charset.*;import java.util.*;import java.util.regex.*;import java.util.zip.*;
public final class Codec {
 public static final int PREVIEW=1024*1024;
 public static byte[] decoded(Model.Message m,int limit)throws IOException {
  InputStream in=m.file.isEmpty()?new ByteArrayInputStream(new byte[0]):new FileInputStream(m.file);
  String encoding=m.header("Content-Encoding").toLowerCase(Locale.ROOT);
  try{if(encoding.equals("gzip"))in=new GZIPInputStream(in);else if(encoding.equals("deflate")){PushbackInputStream probe=new PushbackInputStream(in,2);int a=probe.read(),b=probe.read();if(b>=0)probe.unread(b);if(a>=0)probe.unread(a);boolean zlib=a>=0&&b>=0&&(a&15)==8&&((a<<8)+b)%31==0;in=new InflaterInputStream(probe,new Inflater(!zlib));}else if(!encoding.isEmpty()&&!encoding.equals("identity"))throw new IOException("暂不支持压缩："+encoding);
   try(InputStream src=in;ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=src.read(b))!=-1){if(o.size()+n>limit)throw new IOException("解码超出预览上限，请导出原始正文");o.write(b,0,n);}return o.toByteArray();}
  }catch(IOException e){try{in.close();}catch(Exception ignored){}throw e;}
 }
 public static Charset charset(Model.Message m,String override,byte[] b){if(override!=null&&!override.isEmpty())try{return Charset.forName(override);}catch(Exception ignored){}
  if(b.length>=3&&(b[0]&255)==239&&(b[1]&255)==187&&(b[2]&255)==191)return StandardCharsets.UTF_8;if(b.length>=2&&(b[0]&255)==255&&(b[1]&255)==254)return StandardCharsets.UTF_16LE;if(b.length>=2&&(b[0]&255)==254&&(b[1]&255)==255)return StandardCharsets.UTF_16BE;
  String info=m.header("Content-Type");Matcher matcher=Pattern.compile("charset\\s*=\\s*[\\\"']?([A-Za-z0-9._-]+)",2).matcher(info);if(matcher.find())try{return Charset.forName(matcher.group(1));}catch(Exception ignored){}
  String pre=new String(b,0,Math.min(b.length,8192),StandardCharsets.ISO_8859_1);matcher=Pattern.compile("<meta[^>]*charset\\s*=\\s*[\\\"']?([A-Za-z0-9._-]+)",2).matcher(pre);if(matcher.find())try{return Charset.forName(matcher.group(1));}catch(Exception ignored){}return StandardCharsets.UTF_8;}
 public static String text(Model.Message m,String override)throws IOException {String mime=m.header("Content-Type").toLowerCase(Locale.ROOT);if(!mime.isEmpty()&&!mime.startsWith("text/")&&!mime.matches(".*(json|xml|javascript|x-www-form-urlencoded|svg).*"))throw new IOException("二进制内容，请使用图片或Hex预览");byte[] b=decoded(m,PREVIEW);String result=new String(b,charset(m,override,b));return result.startsWith("\ufeff")?result.substring(1):result;}
 public static void edit(Model.Message m,String text,String headers,String line)throws IOException {
  if(line.indexOf('\n')>=0||line.indexOf('\r')>=0)throw new IOException("首行不能包含换行");
  ArrayList<String> parsed=new ArrayList<>();for(String h:headers.split("\\r?\\n")){if(h.trim().isEmpty())continue;int p=h.indexOf(':');if(p<1||!h.substring(0,p).matches("[!#$%&'*+.^_`|~0-9A-Za-z-]+"))throw new IOException("请求/响应头格式错误："+h);if(h.indexOf('\r')>=0||h.indexOf('\u0000')>=0)throw new IOException("头部含非法字符");parsed.add(h);}
  m.line=line;m.headers=parsed;m.set("Content-MD5",null);m.set("Digest",null);m.set("ETag",null);m.set("Content-Encoding",null);m.set("Transfer-Encoding",null);m.set("Content-Length",null);String ct=m.header("Content-Type");if(ct.isEmpty())ct="text/plain";ct=ct.replaceAll("(?i);\\s*charset=[^;]+","");m.set("Content-Type",ct+"; charset=utf-8");m.bytes(text.getBytes(StandardCharsets.UTF_8));
 }
 public static String rawHeaders(Model.Message m){return String.join("\n",m.headers);}
}
