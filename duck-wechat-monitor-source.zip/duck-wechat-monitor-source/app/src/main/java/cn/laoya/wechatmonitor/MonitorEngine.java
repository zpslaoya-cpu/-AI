package cn.laoya.wechatmonitor;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public final class MonitorEngine {
    private MonitorEngine() {}
    public interface Listener { void onProgress(String detail); }
    public static synchronized String run(Context context,boolean force,Listener listener) {
        Store store=new Store(context.getApplicationContext());
        try {
            String template=store.getSetting("feed_template");
            if(template.isEmpty())return "尚未配置文章来源。请到设置填写 HTTPS 文章数据接口。";
            JSONArray accounts=store.duePublishers(force);
            int success=0,failed=0,added=0,skipped=0;
            for(int i=0;i<accounts.length();i++) {
                JSONObject publisher=accounts.getJSONObject(i);
                int id=publisher.getInt("id");String name=publisher.getString("name");
                if(listener!=null)listener.onProgress("正在检查："+name+" ("+(i+1)+"/"+accounts.length()+")");
                try{
                    String key=publisher.optString("original_id");
                    if(key.isEmpty()) {store.logCheck(id,"跳过",0,0,"未填写原始 ID，无法匹配数据源");skipped++;continue;}
                    String endpoint=template.replace("{id}",URLEncoder.encode(key,"UTF-8")).replace("{name}",URLEncoder.encode(name,"UTF-8"));
                    if(!endpoint.startsWith("https://"))throw new Exception("数据源必须使用 HTTPS");
                    URL target=new URL(endpoint);
                    if(!"https".equalsIgnoreCase(target.getProtocol()))throw new Exception("拒绝非 HTTPS 数据源");
                    HttpURLConnection con=(HttpURLConnection)target.openConnection();con.setConnectTimeout(12000);con.setReadTimeout(18000);con.setInstanceFollowRedirects(false);con.setRequestProperty("Accept","application/json");con.setRequestProperty("User-Agent","DuckWechatMonitor/1.0");
                    int status=con.getResponseCode();
                    if(status==429){store.logCheck(id,"限流",0,0,"HTTP 429：数据源限流");failed++;con.disconnect();continue;}
                    if(status!=200){con.disconnect();throw new Exception("数据源 HTTP "+status);}
                    byte[] body;
                    try(InputStream input=con.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                        byte[] buffer=new byte[4096];int read;while((read=input.read(buffer))!=-1){out.write(buffer,0,read);if(out.size()>2_000_000)throw new Exception("响应超过 2MB");}body=out.toByteArray();
                    }finally{con.disconnect();}
                    JSONObject data=new JSONObject(new String(body,StandardCharsets.UTF_8));
                    if(!data.has("articles")||!(data.opt("articles") instanceof JSONArray))throw new Exception("响应缺少 articles 数组");
                    JSONArray articles=data.getJSONArray("articles");
                    int inserted=0,rejected=0;
                    for(int k=0;k<Math.min(articles.length(),200);k++){
                        JSONObject a=articles.optJSONObject(k);if(a==null){rejected++;continue;}
                        int result=store.addArticle(id,a.optString("title"),a.optString("url"),a.optString("published_at"));
                        if(result>0)inserted++;else if(result<0)rejected++;
                    }
                    String outcome=rejected>0?"部分成功":"成功";
                    store.logCheck(id,outcome,articles.length(),inserted,rejected>0?("跳过 "+rejected+" 条无效文章"):"");
                    success++;added+=inserted;
                }catch(Exception e){failed++;store.logCheck(id,"失败",0,0,safeMessage(e));}
            }
            return "检测结束：成功 "+success+"，失败 "+failed+"，跳过 "+skipped+"，新增文章 "+added+" 篇";
        }catch(Exception e){return "检查失败："+safeMessage(e);}
        finally{store.close();}
    }
    private static String safeMessage(Exception e){String s=e.getMessage();if(s==null)s=e.getClass().getSimpleName();return s.length()>180?s.substring(0,180):s;}
}
