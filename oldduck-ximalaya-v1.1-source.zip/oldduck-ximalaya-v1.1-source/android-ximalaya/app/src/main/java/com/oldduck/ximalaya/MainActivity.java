package com.oldduck.ximalaya;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.security.KeyStore;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.math.BigDecimal;
import java.math.RoundingMode;

public final class MainActivity extends Activity {
    private static final int SAVE_TXT = 1004;
    private static final int IMPORT_LEGACY = 1005;
    private static final String APP_URL = "file:///android_asset/index.html";
    private static final String GROUP = "https://qun.qq.com/universal-share/share?ac=1&authKey=lL1%2B4YEfB7L2hOTOIs81ePR1nu4rEIsEtps%2B9uwQos0X7ic3aYaA1uenl3yVriVu&busi_data=eyJncm91cENvZGUiOiIxMDUxNDg0MDM0IiwidG9rZW4iOiJ0NnJGVmN6VGlLc1ZpK2lUQkZyY1U2SXBreG4vWnYrVmNQZm9nMXV5eThaWHhlajhkVDFIWjhUZTcxZ29palhEIiwidWluIjoiMzU5MTM2NzY0MyJ9&data=Mlg49RfTjSEo83WP1wHuMKTpm2qfI3lLojvxsW80DtH5T4rfziCIRbIJZsHQlRm89I7ZWrdnE2xZJ5GhE3v7Gw&svctype=4&tempid=h5_group_info";
    private WebView web;
    private Store store;
    private String pendingExport;
    private static final int MAX_IMPORT_BYTES = 2_000_000;

    private static String now() { return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ROOT)); }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff0b1222);
        getWindow().setNavigationBarColor(0xff0b1222);
        store = new Store(this);
        web = new WebView(this);
        setContentView(web);
        WebSettings w = web.getSettings();
        w.setJavaScriptEnabled(true);
        w.setDomStorageEnabled(true);
        w.setAllowFileAccess(true);
        w.setAllowContentAccess(false);
        w.setAllowFileAccessFromFileURLs(false);
        w.setAllowUniversalAccessFromFileURLs(false);
        w.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String s = req.getUrl().toString();
                if (s.startsWith("file:///android_asset/")) return false;
                return true; // external navigation is never performed inside bridge-enabled WebView
            }
        });
        web.addJavascriptInterface(new Bridge(), "DuckNative");
        web.loadUrl(APP_URL);
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("window.DuckApp&&DuckApp.goBack()",null);
    }
    @Override protected void onDestroy() { if (web != null) { web.removeJavascriptInterface("DuckNative"); web.destroy(); } if(store != null) store.close(); super.onDestroy(); }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request == IMPORT_LEGACY) {
            if (result == RESULT_OK && data != null && data.getData() != null) {
                String outcome;
                try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                    if (in == null) throw new Exception("没有读取权限");
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    byte[] block = new byte[8192]; int n;
                    while ((n = in.read(block)) != -1) {
                        if (bytes.size() + n > MAX_IMPORT_BYTES) throw new Exception("文件超过 2MB 限制");
                        bytes.write(block,0,n);
                    }
                    String raw = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
                    if (raw.startsWith("\ufeff")) raw = raw.substring(1);
                    outcome = store.importLegacyJson(raw);
                } catch (Exception e) {
                    outcome = Store.reply(false,"导入失败：" + e.getClass().getSimpleName());
                }
                final String resultJson = outcome;
                web.evaluateJavascript("window.DuckApp&&DuckApp.legacyResult(" + JSONObject.quote(resultJson) + ")",null);
            }
            return;
        }
        if(request == SAVE_TXT && result == RESULT_OK && data != null && data.getData()!=null && pendingExport!=null) {
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if(out==null) throw new Exception("Cannot open document");
                out.write(new byte[]{(byte)0xef,(byte)0xbb,(byte)0xbf});
                out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this,"TXT 已保存",Toast.LENGTH_SHORT).show();
            } catch(Exception e) { Toast.makeText(this,"保存失败: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        }
        pendingExport=null;
    }

    final class Bridge {
        @JavascriptInterface public String snapshot() { return store.snapshot(); }
        @JavascriptInterface public String account(String uid,String remark) { return store.upsert(uid,remark); }
        @JavascriptInterface public String importAccounts(String input) { return store.importAccounts(input); }
        @JavascriptInterface public String removeAccount(String uid) { return store.remove(uid); }
        @JavascriptInterface public String record(String uid,String kind,String result,String amount,String note) { return store.record(uid,kind,result,amount,note); }
        @JavascriptInterface public String addLog(String level,String message) { return store.addLog(level,message); }
        @JavascriptInterface public void pickLegacyAccounts() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
                startActivityForResult(i, IMPORT_LEGACY);
            });
        }
        @JavascriptInterface public void exportTxt(String filename,String content) {
            if(content.length()>2_000_000) return;
            pendingExport=content;
            runOnUiThread(() -> {
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/plain");
                String safeName = filename.replaceAll("[^\\p{L}\\p{N}._-]", "_");
                i.putExtra(Intent.EXTRA_TITLE,safeName.substring(0,Math.min(safeName.length(),100)));
                startActivityForResult(i,SAVE_TXT);
            });
        }
        @JavascriptInterface public void openGroup() {
            runOnUiThread(() -> {
                try { Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(GROUP)); i.addCategory(Intent.CATEGORY_BROWSABLE); startActivity(i); }
                catch(Exception e) { Toast.makeText(MainActivity.this,"没有可打开链接的浏览器",Toast.LENGTH_LONG).show(); }
            });
        }
    }

    static final class Store extends SQLiteOpenHelper {
        Store(Context c){ super(c,"oldduck.db",null,2); }
        @Override public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE accounts(uid TEXT PRIMARY KEY COLLATE NOCASE, remark TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)");
            d.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL, kind TEXT NOT NULL, result TEXT NOT NULL, amount_minor INTEGER, note TEXT, created_at TEXT NOT NULL)");
            d.execSQL("CREATE INDEX ev_date ON events(created_at)");
            d.execSQL("CREATE INDEX ev_uid ON events(uid)");
            d.execSQL("CREATE TABLE logs(id INTEGER PRIMARY KEY AUTOINCREMENT, level TEXT NOT NULL, message TEXT NOT NULL, created_at TEXT NOT NULL)");
            d.execSQL("CREATE TABLE account_auth(uid TEXT PRIMARY KEY COLLATE NOCASE, cookie_enc TEXT NOT NULL, proxy_enc TEXT, imported_at TEXT NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int old,int current){
            if (old < 2) d.execSQL("CREATE TABLE IF NOT EXISTS account_auth(uid TEXT PRIMARY KEY COLLATE NOCASE, cookie_enc TEXT NOT NULL, proxy_enc TEXT, imported_at TEXT NOT NULL)");
        }
        private static final String KEY_ALIAS = "oldduck.ximalaya.legacy.v1";
        private static String encrypt(String input) throws Exception {
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
            SecretKey key;
            if(!ks.containsAlias(KEY_ALIAS)) {
                KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
                kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256).build());
                key=kg.generateKey();
            } else key=(SecretKey) ks.getKey(KEY_ALIAS,null);
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,key);
            return Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(cipher.doFinal(input.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
        }
        /** Parse original Windows xmly_accounts.json with no network requests or plaintext secret export. */
        synchronized String importLegacyJson(String input) {
            if(input==null||input.length()>MAX_IMPORT_BYTES) return reply(false,"文件过大");
            JSONArray accounts;
            try { accounts=new JSONArray(input); }
            catch(Exception e) {
                try { JSONObject root=new JSONObject(input); accounts=root.optJSONArray("accounts"); }
                catch(Exception ex) { return reply(false,"请选择原版 xmly_accounts.json（JSON 数组）"); }
            }
            if(accounts==null||accounts.length()>500) return reply(false,"文件结构不正确或超过 500 个账号");
            final Pattern uidPattern=Pattern.compile("(?:^|[&;])\\s*_token=(\\d+)(?:&|;|$)");
            SQLiteDatabase d=getWritableDatabase(); int added=0,updated=0,skipped=0;
            // Parse and encrypt everything first to prevent half-imports on malformed input.
            JSONArray safeRows=new JSONArray();
            try {
                for(int j=0;j<accounts.length();j++) {
                    JSONObject a=accounts.optJSONObject(j); if(a==null){skipped++;continue;}
                    String cookie=a.optString("cookie","");
                    if(cookie.length()>20000 || cookie.length()<6){skipped++;continue;}
                    String uid=a.optString("uid","").trim();
                    Matcher m=uidPattern.matcher(cookie);
                    String cookieUid=m.find()?m.group(1):"";
                    if(uid.isEmpty())uid=cookieUid;
                    if(!cookieUid.isEmpty() && !uid.equals(cookieUid)){skipped++;continue;}
                    if(uid.length()<2 || uid.length()>64 || !uid.matches("[0-9A-Za-z._-]+")){skipped++;continue;}
                    String remark=clean(a.optString("remark", a.optString("name","")),80);
                    String proxy=a.optString("proxy","");
                    if(proxy.length()>500) {skipped++;continue;}
                    JSONObject row=new JSONObject().put("uid",uid).put("remark",remark)
                         .put("cookie",encrypt(cookie)).put("proxy",proxy.isEmpty()?JSONObject.NULL:encrypt(proxy));
                    safeRows.put(row);
                }
                if(safeRows.length()==0) return reply(false,"没有识别到带 Cookie 的有效账号，请检查文件格式");
                d.beginTransaction();
                for(int j=0;j<safeRows.length();j++){
                    JSONObject row=safeRows.getJSONObject(j);
                    String uid=row.getString("uid"),remark=row.getString("remark");
                    ContentValues a=new ContentValues();a.put("uid",uid);a.put("remark",remark);a.put("created_at",now());
                    long created=d.insertWithOnConflict("accounts",null,a,SQLiteDatabase.CONFLICT_IGNORE);
                    if(created<0){updated++; if(!remark.isEmpty()) {
                        ContentValues cv=new ContentValues(); cv.put("remark",remark);
                        d.update("accounts",cv,"uid=?",new String[]{uid});
                    }} else added++;
                    ContentValues auth=new ContentValues();auth.put("uid",uid);
                    auth.put("cookie_enc",row.getString("cookie"));
                    if(row.isNull("proxy"))auth.putNull("proxy_enc"); else auth.put("proxy_enc",row.getString("proxy"));
                    auth.put("imported_at",now());
                    d.insertWithOnConflict("account_auth",null,auth,SQLiteDatabase.CONFLICT_REPLACE);
                }
                log(d,"INFO","已从原版文件导入凭据（加密保存），新增 " + added + "，更新 " + updated + "，跳过 " + skipped);
                d.setTransactionSuccessful();
                return reply(true,"已导入：新增 " + added + "、更新 " + updated + "、跳过 " + skipped + "。凭据使用 Android Keystore 加密；当前不会联网登录。");
            }catch(Exception e) { return reply(false,"导入出错，未写入：" + e.getClass().getSimpleName()); }
            finally{if(d.inTransaction())d.endTransaction();}
        }
        private static String clean(String s,int max) { if(s==null)return ""; return s.trim().substring(0,Math.min(s.trim().length(),max)); }
        private static String reply(boolean ok,String msg) { try{return new JSONObject().put("ok",ok).put("message",msg).toString();}catch(Exception e){return "{\"ok\":false}";} }
        private void log(SQLiteDatabase d,String lvl,String msg){
            String redacted=msg.replaceAll("(?i)(authorization|cookie|token|password|ticket|secret|authkey)(\\s*[:=]\\s*)([^\\s;&]+)","$1$2[已隐藏]");
            ContentValues v=new ContentValues(); v.put("level",lvl);v.put("message",clean(redacted,600));v.put("created_at",now());d.insert("logs",null,v);
            d.execSQL("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 3000)");
        }
        synchronized String upsert(String id,String label) {
            String uid=clean(id,64), remark=clean(label,80);
            if(uid.isEmpty()||uid.length()<2)return reply(false,"账号 UID 至少两个字符");
            SQLiteDatabase d=getWritableDatabase();
            try{
                ContentValues v=new ContentValues();v.put("uid",uid);v.put("remark",remark);v.put("created_at",now());
                d.insertWithOnConflict("accounts",null,v,SQLiteDatabase.CONFLICT_IGNORE);
                ContentValues upd=new ContentValues();upd.put("remark",remark);d.update("accounts",upd,"uid=?",new String[]{uid});
                log(d,"SUCCESS","保存账号 "+uid);
                return reply(true,"账号已保存");
            }catch(Exception e){return reply(false,e.getMessage());}
        }
        synchronized String importAccounts(String input) {
            if(input==null||input.length()>150000) return reply(false,"导入内容过长");
            String[] lines=input.split("\\r?\\n");
            SQLiteDatabase d=getWritableDatabase(); int added=0,skipped=0;
            d.beginTransaction();
            try {
                for(String line:lines){
                    line=line.trim(); if(line.isEmpty())continue;
                    String[] parts=line.split("[,，\\t|]",2); String uid=clean(parts[0],64), remark=parts.length>1?clean(parts[1],80):"";
                    if(uid.length()<2){skipped++;continue;}
                    ContentValues v=new ContentValues();v.put("uid",uid);v.put("remark",remark);v.put("created_at",now());
                    if(d.insertWithOnConflict("accounts",null,v,SQLiteDatabase.CONFLICT_IGNORE)<0){skipped++;}else{added++;}
                }
                log(d,"INFO","批量导入账号：新增 "+added+"，跳过 "+skipped);
                d.setTransactionSuccessful();
                return reply(true,"新增 "+added+" 个账号，跳过 "+skipped+" 条（已存在或无效）");
            }catch(Exception e){return reply(false,e.getMessage());}finally{d.endTransaction();}
        }
        synchronized String remove(String id) {
            String uid=clean(id,64); SQLiteDatabase d=getWritableDatabase();
            int count=d.delete("accounts","uid=?",new String[]{uid});
            d.delete("account_auth","uid=?",new String[]{uid});
            log(d,"INFO","删除账号 "+uid+"，加密凭据一并清除，历史统计记录保留");
            return reply(count>0,count>0?"账号已删除，历史记录保留":"未找到账号");
        }
        synchronized String record(String id,String kind,String result,String amount,String note) {
            String uid=clean(id,64),k=clean(kind,20),r=clean(result,20),memo=clean(note,200),amt=clean(amount,36);
            if(!k.equals("coin")&&!k.equals("withdraw"))return reply(false,"无效类型");
            if(!r.equals("success")&&!r.equals("failure")&&!r.equals("unknown"))return reply(false,"无效状态");
            SQLiteDatabase d=getWritableDatabase();
            try(Cursor c=d.rawQuery("SELECT uid FROM accounts WHERE uid=?",new String[]{uid})) {
                if(!c.moveToFirst())return reply(false,"请先添加账号");
            }
            Long minor=null;
            if(!amt.isEmpty()) {
                try{
                    BigDecimal a=new BigDecimal(amt);
                    if(a.signum()<0||a.compareTo(new BigDecimal("100000000"))>0)return reply(false,"数量超出范围");
                    if(k.equals("coin"))minor=a.setScale(0,RoundingMode.UNNECESSARY).longValueExact();
                    else minor=a.multiply(new BigDecimal("100")).setScale(0,RoundingMode.UNNECESSARY).longValueExact();
                }catch(Exception e){return reply(false,k.equals("coin")?"金币必须是整数":"提现金额最多两位小数");}
            }
            ContentValues v=new ContentValues();v.put("uid",uid);v.put("kind",k);v.put("result",r);
            if(minor==null)v.putNull("amount_minor");else v.put("amount_minor",minor);
            v.put("note",memo);v.put("created_at",now());
            d.insertOrThrow("events",null,v);
            log(d,"INFO","记录 "+uid+" / "+(k.equals("coin")?"金币":"提现")+" / "+r+(minor==null?" / 收益未记录":" / 数量已记录"));
            return reply(true,"记录成功，已写入本地数据库");
        }
        synchronized String addLog(String level,String message){
            String l=clean(level,16);if(!l.equals("INFO")&&!l.equals("SUCCESS")&&!l.equals("ERROR"))l="INFO";
            log(getWritableDatabase(),l,clean(message,600));return reply(true,"日志已保存");
        }
        synchronized String snapshot() {
            JSONObject obj=new JSONObject();SQLiteDatabase d=getReadableDatabase();
            try{
                JSONArray ac=new JSONArray(),ev=new JSONArray(),lg=new JSONArray();
                try(Cursor c=d.rawQuery("SELECT a.uid,a.remark,a.created_at,CASE WHEN s.uid IS NULL THEN 0 ELSE 1 END FROM accounts a LEFT JOIN account_auth s ON a.uid=s.uid ORDER BY a.created_at DESC,a.uid",null)) {
                    while(c.moveToNext())ac.put(new JSONObject().put("uid",c.getString(0)).put("remark",c.getString(1)).put("created_at",c.getString(2)).put("has_local_credential",c.getInt(3)==1));
                }
                try(Cursor c=d.rawQuery("SELECT id,uid,kind,result,amount_minor,note,created_at FROM events ORDER BY id DESC LIMIT 20000",null)) {
                    while(c.moveToNext()) { JSONObject e=new JSONObject().put("id",c.getLong(0)).put("uid",c.getString(1)).put("kind",c.getString(2)).put("result",c.getString(3)).put("note",c.getString(5)).put("created_at",c.getString(6));
                        if(c.isNull(4))e.put("amount_minor",JSONObject.NULL);else e.put("amount_minor",c.getLong(4));ev.put(e);
                    }
                }
                try(Cursor c=d.rawQuery("SELECT level,message,created_at FROM logs ORDER BY id DESC LIMIT 2000",null)) {
                    while(c.moveToNext())lg.put(new JSONObject().put("level",c.getString(0)).put("message",c.getString(1)).put("created_at",c.getString(2)));
                }
                obj.put("accounts",ac);obj.put("events",ev);obj.put("logs",lg);obj.put("generated_at",now());
            }catch(JSONException e){ return "{\"accounts\":[],\"events\":[],\"logs\":[]}"; }
            return obj.toString();
        }
    }
}
