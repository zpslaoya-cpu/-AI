package cn.laoya.capture;
import java.io.*;import java.net.*;import java.nio.charset.*;
public class ReplayTest {
 static final Charset L=StandardCharsets.ISO_8859_1;
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static String req(String url,String extra,String body){return "POST "+url+" HTTP/1.1\r\nHost: test\r\nContent-Type: application/json; charset=utf-8\r\n"+extra+"Content-Length: "+body.getBytes(StandardCharsets.UTF_8).length+"\r\n\r\n"+new String(body.getBytes(StandardCharsets.UTF_8),L);}
 static void reject(String raw,boolean clipped)throws Exception {try{ReplayRequest.parse(raw,clipped);throw new AssertionError("should reject");}catch(IOException expected){}}
 public static void main(String[] a)throws Exception {
  String raw=req("http://example.com/api","Connection: X-Test\r\nX-Test: hidden\r\nCookie: demo=local\r\n","{\"n\":1}");ReplayRequest r=ReplayRequest.parse(raw,false);String body="{\"昵称\":\"老鸭\"}";byte[] b=r.wire(body);String w=new String(b,L);
  check(w.contains("Content-Length: "+body.getBytes(StandardCharsets.UTF_8).length+"\r\n"),"UTF8 byte length");check(!w.contains("X-Test:"),"connection-nominated header removed");check(w.contains("Cookie: demo=local"),"header retained");check(w.endsWith(new String(body.getBytes(StandardCharsets.UTF_8),L)),"edited body encoded");
  reject(raw,true);reject(raw.substring(0,raw.length()-1),false);reject("CONNECT example.com:443 HTTP/1.1\r\n\r\n",false);reject(raw.replace("http://example.com","https://example.com"),false);reject(raw.replace("Content-Length:","Transfer-Encoding: chunked\r\nContent-Length:"),false);reject(raw.replace("Content-Length:","Content-Encoding: gzip\r\nContent-Length:"),false);
  try(ServerSocket origin=new ServerSocket(0,1,InetAddress.getLoopbackAddress());LocalProxy proxy=new LocalProxy(s->s.isBound()&&!s.isConnected())){
   proxy.start();final String[] got={null};Thread t=new Thread(()->{try(Socket c=origin.accept()){BufferedReader in=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8));String line;int len=0;while(!(line=in.readLine()).isEmpty())if(line.startsWith("Content-Length:"))len=Integer.parseInt(line.substring(15).trim());char[] chars=new char[len];int n=in.read(chars);got[0]=new String(chars,0,n);c.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok".getBytes());}catch(Exception e){throw new RuntimeException(e);}});t.start();
   ReplayRequest local=ReplayRequest.parse(req("http://127.0.0.1:"+origin.getLocalPort()+"/api","","{\"n\":1}"),false);proxy.replay(local.wire("{\"n\":20}"));t.join();check("{\"n\":20}".equals(got[0]),"edited body reaches local server");check(Records.snapshot().get(0).responseText().contains("ok"),"replay response captured");
  }
  System.out.println("PASS: UTF8 length, header preservation, hop header removal, truncated/TLS/compressed/chunked rejection, real local replay capture");
 }
}
