package cn.laoya.wechatmonitor;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.HashSet;

public class Store extends SQLiteOpenHelper {
    private static final String DB="duck_wechat_monitor.db";
    public Store(Context c) { super(c,DB,null,1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE publishers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,original_id TEXT NOT NULL DEFAULT '',enabled INTEGER NOT NULL DEFAULT 1,last_check INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT '未检测',last_error TEXT NOT NULL DEFAULT '',UNIQUE(name,original_id))");
        db.execSQL("CREATE TABLE articles (id INTEGER PRIMARY KEY AUTOINCREMENT,publisher_id INTEGER NOT NULL,title TEXT NOT NULL,url TEXT NOT NULL,article_key TEXT NOT NULL,published_at TEXT NOT NULL DEFAULT '',discovered_at INTEGER NOT NULL,UNIQUE(publisher_id,article_key),FOREIGN KEY(publisher_id) REFERENCES publishers(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX idx_articles_discovered ON articles(discovered_at DESC)");
        db.execSQL("CREATE INDEX idx_articles_published ON articles(published_at DESC)");
        db.execSQL("CREATE TABLE fetch_runs (id INTEGER PRIMARY KEY AUTOINCREMENT,publisher_id INTEGER NOT NULL,status TEXT NOT NULL,fetched INTEGER NOT NULL DEFAULT 0,added INTEGER NOT NULL DEFAULT 0,message TEXT NOT NULL DEFAULT '',executed_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE settings (key TEXT PRIMARY KEY,value TEXT NOT NULL)");
    }
    @Override public void onConfigure(SQLiteDatabase db){ super.onConfigure(db);db.setForeignKeyConstraintsEnabled(true); }
    @Override public void onUpgrade(SQLiteDatabase db,int from,int to) { /* preserve data on future migrations */ }
    public synchronized int addPublisher(String name,String originalId) {
        name=name==null?"":name.trim(); originalId=originalId==null?"":originalId.trim();
        if (name.isEmpty()||name.length()>100||originalId.length()>120) return -1;
        ContentValues v=new ContentValues();v.put("name",name);v.put("original_id",originalId);
        long id=getWritableDatabase().insertWithOnConflict("publishers",null,v,SQLiteDatabase.CONFLICT_IGNORE);
        return id>0?(int)id:0;
    }
    public synchronized int importBatch(String raw) {
        if (raw==null || raw.length()>100000) return -1;
        int added=0;
        for(String line:raw.split("\\r?\\n")) {
            String s=line.trim(); if(s.isEmpty())continue;
            String[] fields=s.split("[,，\\t]",2);
            if(addPublisher(fields[0], fields.length>1?fields[1]:"")>0) added++;
        }
        return added;
    }
    public synchronized void deletePublisher(int id) {
        if(id>0)getWritableDatabase().delete("publishers","id=?",new String[]{String.valueOf(id)});
    }
    public synchronized void togglePublisher(int id) {
        SQLiteDatabase d=getWritableDatabase();
        d.execSQL("UPDATE publishers SET enabled=1-enabled WHERE id=?",new Object[]{id});
    }
    public synchronized void setSetting(String key,String value) {
        if(!"feed_template".equals(key))return;
        if(value==null)value=""; value=value.trim();
        if(value.length()>1500)throw new IllegalArgumentException("接口地址过长");
        if(!value.isEmpty() && !value.startsWith("https://"))throw new IllegalArgumentException("文章来源必须是 HTTPS 地址");
        ContentValues v=new ContentValues();v.put("key",key);v.put("value",value);
        getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public synchronized String getSetting(String key) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT value FROM settings WHERE key=?",new String[]{key})) {return c.moveToFirst()?c.getString(0):"";}
    }
    public synchronized JSONArray duePublishers(boolean force) throws Exception {
        JSONArray result=new JSONArray();long threshold=System.currentTimeMillis()-120*60*1000L;
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,original_id,last_check FROM publishers WHERE enabled=1 AND (?=1 OR last_check<=?) ORDER BY last_check ASC LIMIT 40",new String[]{force?"1":"0",String.valueOf(threshold)})){
            while(c.moveToNext()) { JSONObject o=new JSONObject();o.put("id",c.getInt(0));o.put("name",c.getString(1));o.put("original_id",c.getString(2));result.put(o); }
        }
        return result;
    }
    public synchronized void logCheck(int id,String status,int fetched,int added,String message) {
        SQLiteDatabase d=getWritableDatabase();
        d.beginTransaction();try {
            long now=System.currentTimeMillis();
            ContentValues p=new ContentValues();p.put("last_check",now);p.put("status",status);p.put("last_error",message);
            d.update("publishers",p,"id=?",new String[]{String.valueOf(id)});
            ContentValues v=new ContentValues();v.put("publisher_id",id);v.put("status",status);v.put("fetched",fetched);v.put("added",added);v.put("message",message);v.put("executed_at",now);
            d.insert("fetch_runs",null,v);
            d.execSQL("DELETE FROM fetch_runs WHERE id NOT IN (SELECT id FROM fetch_runs ORDER BY id DESC LIMIT 500)");
            d.setTransactionSuccessful();
        }finally {d.endTransaction();}
    }
    public synchronized int addArticle(int publisherId,String title,String url,String publishedAt) {
        title=title==null?"":title.trim();url=url==null?"":url.trim();publishedAt=publishedAt==null?"":publishedAt.trim();
        if (publisherId<=0||title.isEmpty()||title.length()>500||url.length()>4000||!url.startsWith("https://")||publishedAt.length()>60) return -1;
        Uri uri=Uri.parse(url); if (uri.getHost()==null)return -1;
        String key=articleKey(url);
        ContentValues v=new ContentValues();v.put("publisher_id",publisherId);v.put("title",title);v.put("url",url);v.put("article_key",key);v.put("published_at",publishedAt);v.put("discovered_at",System.currentTimeMillis());
        return getWritableDatabase().insertWithOnConflict("articles",null,v,SQLiteDatabase.CONFLICT_IGNORE)>0?1:0;
    }
    private static String articleKey(String url) {
        try {
            Uri u=Uri.parse(url);
            String biz=u.getQueryParameter("__biz"),mid=u.getQueryParameter("mid"),idx=u.getQueryParameter("idx");
            String source;
            if(biz!=null && mid!=null && idx!=null && "mp.weixin.qq.com".equalsIgnoreCase(u.getHost())) source="wx|"+biz+"|"+mid+"|"+idx;
            else {
                Uri.Builder b=u.buildUpon().clearQuery();
                HashSet<String> tracking=new HashSet<>();
                for(String k:new String[]{"scene","chksm","from","isappinstalled","share_token","utm_source","utm_medium","utm_campaign","utm_term","utm_content"})tracking.add(k);
                for(String k:u.getQueryParameterNames()) if(!tracking.contains(k.toLowerCase(Locale.ROOT)))for(String val:u.getQueryParameters(k))b.appendQueryParameter(k,val);
                b.fragment(null);source=b.build().toString();
            }
            MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] bytes=digest.digest(source.getBytes(StandardCharsets.UTF_8));StringBuilder hex=new StringBuilder();for(byte b:bytes)hex.append(String.format(Locale.ROOT,"%02x",b&255));return hex.toString();
        }catch(Exception e){return url;}
    }
    public synchronized String snapshot(){
        try{
            JSONObject o=new JSONObject();JSONArray pubs=new JSONArray(),arts=new JSONArray(),runs=new JSONArray();
            SQLiteDatabase db=getReadableDatabase();
            try(Cursor c=db.rawQuery("SELECT id,name,original_id,enabled,last_check,status,last_error,(SELECT COUNT(*) FROM articles a WHERE a.publisher_id=p.id) AS n FROM publishers p ORDER BY id DESC",null)){
                while(c.moveToNext()) {JSONObject p=new JSONObject();p.put("id",c.getInt(0));p.put("name",c.getString(1));p.put("original_id",c.getString(2));p.put("enabled",c.getInt(3)==1);p.put("last_check",c.getLong(4));p.put("status",c.getString(5));p.put("last_error",c.getString(6));p.put("count",c.getInt(7));pubs.put(p);}
            }
            try(Cursor c=db.rawQuery("SELECT a.id,a.publisher_id,p.name,a.title,a.url,a.published_at,a.discovered_at FROM articles a JOIN publishers p ON p.id=a.publisher_id ORDER BY a.discovered_at DESC LIMIT 1500",null)){
                while(c.moveToNext()){JSONObject a=new JSONObject();a.put("id",c.getInt(0));a.put("publisher_id",c.getInt(1));a.put("publisher",c.getString(2));a.put("title",c.getString(3));a.put("url",c.getString(4));a.put("published_at",c.getString(5));a.put("discovered_at",c.getLong(6));arts.put(a);}
            }
            try(Cursor c=db.rawQuery("SELECT r.id,p.name,r.status,r.fetched,r.added,r.message,r.executed_at FROM fetch_runs r LEFT JOIN publishers p ON p.id=r.publisher_id ORDER BY r.id DESC LIMIT 80",null)){
                while(c.moveToNext()){JSONObject a=new JSONObject();a.put("id",c.getInt(0));a.put("publisher",c.getString(1));a.put("status",c.getString(2));a.put("fetched",c.getInt(3));a.put("added",c.getInt(4));a.put("message",c.getString(5));a.put("at",c.getLong(6));runs.put(a);}
            }
            o.put("publishers",pubs);o.put("articles",arts);o.put("runs",runs);o.put("feed_template",getSetting("feed_template"));return o.toString();
        }catch(Exception e){return "{\"error\":"+JSONObject.quote(e.getMessage())+"}";}
    }
}
