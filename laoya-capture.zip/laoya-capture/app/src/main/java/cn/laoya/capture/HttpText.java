package cn.laoya.capture;

import java.io.*;
import java.nio.charset.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

/** Decode captured HTTP/1 message bytes without changing forwarded traffic. */
public final class HttpText {
 private static final int LIMIT=2*1024*1024;
 private static final Charset LATIN=StandardCharsets.ISO_8859_1;
 private static final Pattern CHARSET=Pattern.compile("charset\\s*=\\s*[\\\"']?([A-Za-z0-9._-]+)",Pattern.CASE_INSENSITIVE);
 private static final Pattern META=Pattern.compile("<meta\\b[^>]*>",Pattern.CASE_INSENSITIVE);
 private static final class ChunkResult {byte[] bytes;boolean complete;ChunkResult(byte[] b,boolean c){bytes=b;complete=c;}}
 public static String decode(String raw,boolean clipped){
  if(raw.isEmpty())return "（尚未收到数据；HTTPS隧道不解密正文）";
  byte[] all=raw.getBytes(LATIN);
  int sep=raw.indexOf("\r\n\r\n");
  if(sep<0)return "[HTTP头尚不完整]\n"+raw;
  String head=raw.substring(0,sep);
  byte[] body=Arrays.copyOfRange(all,sep+4,all.length);
  Map<String,String> headers=new HashMap<>();
  String[] lines=head.split("\r\n");
  for(int i=1;i<lines.length;i++){int p=lines[i].indexOf(':');if(p>0){String k=lines[i].substring(0,p).trim().toLowerCase(Locale.ROOT);String v=lines[i].substring(p+1).trim();headers.merge(k,v,(a,b)->a+","+b);}}
  StringBuilder notes=new StringBuilder();
  if(clipped)notes.append("[捕获超过64KiB，正文可能截断]\n");
  String transfer=headers.getOrDefault("transfer-encoding","").toLowerCase(Locale.ROOT);
  if(transfer.contains("chunked")){
   try{ChunkResult chunks=unchunk(body);body=chunks.bytes;if(!chunks.complete)notes.append("[分块数据尚不完整，仅显示已收到部分]\n");}
   catch(Exception e){return head+"\n\n[分块解析失败："+e.getMessage()+"]\n"+hex(body);}
  }
  String ce=headers.getOrDefault("content-encoding","").toLowerCase(Locale.ROOT);
  if(!ce.isEmpty()&&!ce.equals("identity")){
   try{
    String[] enc=ce.split(",");
    for(int i=enc.length-1;i>=0;i--){String c=enc[i].trim();
     if(c.equals("gzip")||c.equals("x-gzip"))body=readLimited(new GZIPInputStream(new ByteArrayInputStream(body)));
     else if(c.equals("deflate"))body=inflate(body);
     else if(!c.equals("identity"))return head+"\n\n[暂不支持压缩格式 "+c+"，显示十六进制]\n"+hex(body);
    }
    notes.append("[已解压 "+ce+"]\n");
   }catch(Exception e){return head+"\n\n[压缩正文不完整或解压失败："+e.getMessage()+"]\n"+hex(body);}
  }
  String ct=headers.getOrDefault("content-type","");
  boolean text=ct.isEmpty()||ct.toLowerCase(Locale.ROOT).startsWith("text/")||ct.toLowerCase(Locale.ROOT).matches(".*(json|xml|javascript|x-www-form-urlencoded|svg).*");
  if(!text)return head+"\n\n[二进制内容 "+ct+"；不按文本解释]\n"+hex(body);
  String charset=null;Matcher cm=CHARSET.matcher(ct);if(cm.find())charset=cm.group(1);
  int skip=0;
  // A byte-order mark takes precedence over an HTML meta declaration.
  if(body.length>=3&&(body[0]&255)==239&&(body[1]&255)==187&&(body[2]&255)==191){charset="UTF-8";skip=3;}
  else if(body.length>=2&&(body[0]&255)==255&&(body[1]&255)==254){charset="UTF-16LE";skip=2;}
  else if(body.length>=2&&(body[0]&255)==254&&(body[1]&255)==255){charset="UTF-16BE";skip=2;}
  if(charset==null){String prefix=new String(body,0,Math.min(body.length,8192),LATIN);Matcher meta=META.matcher(prefix);while(meta.find()){Matcher match=CHARSET.matcher(meta.group());if(match.find()){charset=match.group(1);break;}}}
  if(charset==null)charset="UTF-8";
  Charset cs;
  try{cs=Charset.forName(charset);}catch(Exception e){cs=StandardCharsets.UTF_8;notes.append("[未知字符集 "+charset+"，按UTF-8显示]\n");}
  String decoded=new String(body,skip,body.length-skip,cs);
  return head+"\n\n"+notes+"[正文字符集："+cs.name()+"]\n"+decoded;
 }
 private static ChunkResult unchunk(byte[] b)throws IOException{
  ByteArrayOutputStream out=new ByteArrayOutputStream();int p=0;
  while(p<b.length){int end=-1;for(int i=p;i+1<b.length;i++)if(b[i]==13&&b[i+1]==10){end=i;break;}
   if(end<0)return new ChunkResult(out.toByteArray(),false);
   String size=new String(b,p,end-p,LATIN).split(";",2)[0].trim();long n;
   try{n=Long.parseLong(size,16);}catch(Exception e){throw new IOException("无效块长度");}
   if(n<0||n>LIMIT)throw new IOException("块过大");p=end+2;
   if(n==0)return new ChunkResult(out.toByteArray(),true);
   int available=Math.min((int)n,b.length-p);if(out.size()+available>LIMIT)throw new IOException("正文过大");out.write(b,p,available);
   if(available<n)return new ChunkResult(out.toByteArray(),false);p+=available;
   if(p+2>b.length)return new ChunkResult(out.toByteArray(),false);
   if(b[p]!=13||b[p+1]!=10)throw new IOException("分块分隔符错误");p+=2;
  }
  return new ChunkResult(out.toByteArray(),false);
 }
 private static byte[] readLimited(InputStream in)throws IOException{
  try(InputStream s=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=s.read(b))!=-1){if(out.size()+n>LIMIT)throw new IOException("解压结果超过2MiB预览上限");out.write(b,0,n);}return out.toByteArray();}
 }
 private static byte[] inflate(byte[] b)throws IOException{
  try{return readLimited(new InflaterInputStream(new ByteArrayInputStream(b)));}
  catch(ZipException e){Inflater raw=new Inflater(true);try{return readLimited(new InflaterInputStream(new ByteArrayInputStream(b),raw));}finally{raw.end();}}
 }
 private static String hex(byte[] b){StringBuilder out=new StringBuilder();int count=Math.min(b.length,512);for(int i=0;i<count;i++){out.append(String.format(Locale.ROOT,"%02x ",b[i]&255));if(i%16==15)out.append('\n');}if(count<b.length)out.append("\n（仅预览前512字节）");return out.toString();}
}
