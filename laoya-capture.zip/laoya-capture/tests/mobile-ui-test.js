const fs=require('fs'),vm=require('vm'),assert=require('assert');
const elements=new Map(),store=new Map(),calls=[];
const classes={toggle(){},contains(){return false}};
function element(id){if(!elements.has(id))elements.set(id,{innerHTML:'',textContent:'',value:'',checked:false,style:{},classList:classes,open:false,showModal(){this.open=true},close(){this.open=false},getContext(){return new Proxy({},{get:()=>()=>{}})},clientWidth:360});return elements.get(id);}
const flow={id:7,method:'POST',url:'http://example.com/api?x=<script>',host:'example.com',code:200,status:'HTTP连接结束',start:1000,end:1200,up:100,down:200,reqSize:7,resSize:20,mime:'application/json',error:'',tag:'',note:'',star:false};
const msg={line:'HTTP/1.1 200 OK',headers:'Content-Type: application/json',type:'application/json',body:'{"data":{"id":7,"items":[1,"x"]}}',decoded:true,complete:true,size:20};
const runtime={ok:true,flows:[flow],gates:[],rules:[],sessions:[],templates:[],jobs:[],running:false,app:'测试',mode:'manual',manualPort:8899,state:'已停止'};
const Native={call(op,json){calls.push([op,JSON.parse(json)]);if(op==='state')return JSON.stringify(runtime);if(op==='detail')return JSON.stringify({ok:true,flow,request:{...msg,line:'POST http://example.com/api HTTP/1.1'},response:msg,originalRequest:msg,originalResponse:msg});return JSON.stringify({ok:true});}};
const ctx={console,TextEncoder,TextDecoder,btoa,atob,URL,URLSearchParams,Date,JSON,Math,Number,String,Object,Array,Set,Map,RegExp,devicePixelRatio:1,navigator:{},Native,window:{Native,scrollTo(){}},document:{getElementById:element,querySelectorAll(){return []},querySelector(){return null},activeElement:null,addEventListener(){},body:{classList:classes}},localStorage:{getItem(k){return store.get(k)||null},setItem(k,v){store.set(k,v)}},setInterval(){},setTimeout(){},clearTimeout(){},confirm(){return true},prompt(){return '测试'}};
vm.createContext(ctx);for(const f of ['app.js','mobile.js','toolkit.js','toolkit-ui.js'])vm.runInContext(fs.readFileSync('app/src/main/assets/'+f,'utf8'),ctx);
vm.runInContext(`
for(page=0;page<6;page++){renderPage();if(!$('main').innerHTML.includes('<h2>'))throw Error('missing page '+page);}
if(card(state.flows[0]).includes('<script>'))throw Error('unsafe URL');
if(code('<img src=x onerror=alert(1)>').includes('<img'))throw Error('unsafe source');
if(Dev.path({a:[{id:8}]},'$.a[0].id')!==8)throw Error('JSON path');
try{Dev.path({},'__proto__.x');throw Error('prototype path accepted');}catch(e){if(e.message==='prototype path accepted')throw e;}
const schema=Dev.schema({items:[1,'x']});if(schema.properties.items.items.anyOf.length!==2)throw Error('mixed schema');
if(Dev.flatten({a:{b:1}})[0][0]!=='a.b')throw Error('flatten');
const parsed=Dev.curl("curl 'http://example.com/api' -H 'X-Test: true' --data-raw 'hello'");if(parsed.line!=='POST http://example.com/api HTTP/1.1'||parsed.body!=='hello')throw Error('curl parser');
try{Dev.curl('curl https://example.com');throw Error('HTTPS accepted');}catch(e){if(e.message==='HTTPS accepted')throw e;}
if(!Dev.csv([['=HYPERLINK(x)','a,b']]).includes("'=HYPERLINK"))throw Error('CSV injection guard');
if(Dev.stats(state.flows).p95!==200||Dev.stats(state.flows).tls!==0)throw Error('stats scope');
for(const action of ['proxySettings','proxyHelp','advancedReplay','crawler','compose','importCurl','jsonWorkbench','paramsInspector','diagnose','regexTool','bodySearchAll','settings','jobList']){actions[action]();if(!$('dialogBody').innerHTML.includes('<h2>'))throw Error('modal '+action);}
if(LaoyaKit.tools.length!==100||!tools().includes('开发工具中心'))throw Error('kit integration');kitCatalog();if(!$('dialogBody').innerHTML.includes('100'))throw Error('catalog');kitOpen('json.mergePatch');actions.kitExample();if($('kitInput').value!=='{\"a\":1,\"b\":2}')throw Error('explicit example loading');
openDetail(7);if(!$('dialogBody').innerHTML.includes('概览')||$('dialogBody').innerHTML.includes('<script>'))throw Error('detail rendering');
`,ctx);
assert(element('nav').innerHTML.includes('工具箱'));console.log('PASS: V0.7 toolkit integration and six-page mobile rendering, 13 tool dialogs, JSON path/schema/flatten, curl parsing, stats scope, CSV formula guard, captured HTML escaping');
(async()=>{
 vm.runInContext("kitOpen('json.mergePatch');actions.kitExample();",ctx);
 await vm.runInContext('kitRun()',ctx);
 assert.deepEqual(JSON.parse(vm.runInContext('kitState.result',ctx)),{a:3});
 vm.runInContext("kitPipeline();$('pipeInput').value=' a \\n\\n a ';$('pipeSteps').value=JSON.stringify([{id:'text.trimLines'},{id:'text.blankRemove'},{id:'text.dedupe'}]);actions.pipeSave();",ctx);
 await vm.runInContext('pipeRun()',ctx);
 assert.equal(vm.runInContext('kitState.result',ctx),'a');
 const saved=JSON.parse(store.get('kitPipeline07'));assert.equal(saved.length,3);assert(!JSON.stringify(saved).includes(' a '));
 console.log('PASS: toolkit UI execution, merge output, three-step pipeline and configuration persistence without initial input');
})().catch(e=>{console.error(e);process.exitCode=1;});
