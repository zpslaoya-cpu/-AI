package cn.laoya.capture.pro;
import java.net.*;import java.util.*;import java.io.*;import org.json.*;
public final class Rules implements Engine.Hooks {
 public void apply(Model.Flow f,String side)throws Exception {
  Model.Message m=side.equals("request")?f.request:f.response;
  for(Model.Rule r:Model.rules){if(!r.enabled||!matches(r,f))continue;
   if(!r.action.equals("mock")&&!r.side.equals(side))continue;
   if(r.action.equals("block")||r.action.equals("offline"))throw new IOException("规则阻止："+r.name);
   if(r.action.equals("delay")){if(r.delay>0)Thread.sleep(Math.min(30000,r.delay));continue;}
   if(r.action.equals("rate")){f.rate=Math.max(1,Math.min(10240,r.rate));continue;}
   if(r.action.equals("mock")){if(side.equals("request")){f.response=new Model.Message();f.response.line="HTTP/1.1 "+r.status+" Mock";f.response.set("Content-Type",r.type);f.response.bytes(r.body.getBytes(java.nio.charset.StandardCharsets.UTF_8));f.note="模拟响应 · "+r.name;}continue;}
   if(!r.side.equals(side))continue;
   if(r.action.equals("header")){if(!r.key.matches("[!#$%&'*+.^_`|~0-9A-Za-z-]+")||r.value.contains("\r")||r.value.contains("\n"))throw new IOException("规则头部含非法字符");m.set(r.key,r.value);continue;}
   if(r.action.equals("status")&&side.equals("response")){m.line="HTTP/1.1 "+r.status+" Debug";continue;}
   String text=Codec.text(m,"");
   if(r.action.equals("json")){Object root=new JSONTokener(text).nextValue();String[] keys=r.key.split("\\.");Object obj=root;for(int i=0;i<keys.length-1;i++)obj=obj instanceof JSONObject?((JSONObject)obj).get(keys[i]):((JSONArray)obj).get(Integer.parseInt(keys[i]));Object value;try{value=new JSONTokener(r.value).nextValue();}catch(Exception e){value=r.value;}String k=keys[keys.length-1];if(obj instanceof JSONObject)((JSONObject)obj).put(k,value);else ((JSONArray)obj).put(Integer.parseInt(k),value);text=root.toString();}
   else if(r.action.equals("replace")){if(r.regex){if(r.find.length()>256)throw new IOException("正则长度超过256");text=text.replaceAll(r.find,r.replace);}else text=text.replace(r.find,r.replace);}
   else if(r.action.equals("body"))text=r.body;
   Codec.edit(m,text,Codec.rawHeaders(m),m.line);
  }
 }
 public static boolean matches(Model.Rule r,Model.Flow f){if(!r.method.isEmpty()&&!r.method.equalsIgnoreCase(f.method))return false;if(!r.host.isEmpty()&&!f.host.toLowerCase(Locale.ROOT).contains(r.host.toLowerCase(Locale.ROOT)))return false;if(!r.path.isEmpty())try{if(!URI.create(f.url).getRawPath().contains(r.path))return false;}catch(Exception e){return false;}return !f.tls;}
}
