package cn.laoya.capture;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
public final class LocalProxy implements AutoCloseable {
 public interface Protector { boolean protect(Socket s); }
 private final Protector protector;
 private final Set<Socket> sockets=ConcurrentHashMap.newKeySet();
 private final Semaphore slots=new Semaphore(12);
 private final ExecutorService workers=Executors.newCachedThreadPool();
 private ServerSocket server;
 private volatile boolean stopped;
 public LocalProxy(Protector p){protector=p;}
 public void start() throws IOException {
  server=new ServerSocket(0,32,InetAddress.getByName("127.0.0.1"));
  workers.execute(()->{while(!stopped)try{Socket c=server.accept();if(!slots.tryAcquire()){c.close();continue;}sockets.add(c);workers.execute(()->{try{handle(c);}finally{sockets.remove(c);try{c.close();}catch(IOException ignored){}slots.release();}});}catch(IOException e){if(!stopped)Records.state="代理监听错误："+e.getMessage();}});
 }
 public int port(){return server.getLocalPort();}
 private static String header(InputStream in)throws IOException{
  ByteArrayOutputStream b=new ByteArrayOutputStream();int state=0;
  byte[] end={13,10,13,10};
  while(b.size()<65536){int c=in.read();if(c<0)throw new EOFException("请求头未完整接收");b.write(c);state=c==end[state]?state+1:(c==13?1:0);if(state==4)return b.toString("ISO-8859-1");}
  throw new IOException("请求头超过64KiB");
 }
 private void handle(Socket client){
  Records.Entry rec=null;Socket upstream=new Socket();sockets.add(upstream);
  try{
   client.setSoTimeout(30000);InputStream ci=client.getInputStream();OutputStream co=client.getOutputStream();
   String h=header(ci);String[] first=h.substring(0,h.indexOf("\r\n")).split(" ",3);if(first.length!=3)throw new IOException("请求行无效");
   boolean tls=first[0].equalsIgnoreCase("CONNECT");
   URI uri=tls?new URI("https://"+first[1]):new URI(first[1]);
   if(!tls&&!"http".equalsIgnoreCase(uri.getScheme()))throw new IOException("仅支持HTTP代理请求及CONNECT");
   String host=uri.getHost();int port=uri.getPort()<0?(tls?443:80):uri.getPort();if(host==null||port<1||port>65535)throw new IOException("目标地址无效");
   rec=Records.add(first[0]+" "+first[1]);byte[] hb=h.getBytes(StandardCharsets.ISO_8859_1);rec.append(true,hb,hb.length);
   if(!protector.protect(upstream))throw new IOException("无法保护外连Socket");
   upstream.connect(new InetSocketAddress(host,port),15000);upstream.setSoTimeout(60000);OutputStream uo=upstream.getOutputStream();
   if(tls){co.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1));co.flush();rec.status="HTTPS加密隧道（不解密正文）";}
   else{
    String path=uri.getRawPath();if(path==null||path.isEmpty())path="/";if(uri.getRawQuery()!=null)path+="?"+uri.getRawQuery();
    StringBuilder wire=new StringBuilder(first[0]+" "+path+" "+first[2]+"\r\n");
    for(String line:h.substring(h.indexOf("\r\n")+2).split("\r\n")){String low=line.toLowerCase(Locale.ROOT);if(!line.isEmpty()&&!low.startsWith("proxy-connection:")&&!low.startsWith("proxy-authorization:")&&!low.startsWith("connection:"))wire.append(line).append("\r\n");}
    wire.append("Connection: close\r\n\r\n");byte[] out=wire.toString().getBytes(StandardCharsets.ISO_8859_1);uo.write(out);uo.flush();rec.up=out.length;rec.status="HTTP传输中";
   }
   final Records.Entry entry=rec;
   Future<?> upload=workers.submit(()->{try{pump(ci,uo,entry,true,!tls);upstream.shutdownOutput();}catch(IOException ignored){}});
   pump(upstream.getInputStream(),co,rec,false,!tls);
   upload.cancel(true);
   rec.status=tls?"HTTPS隧道结束（正文加密）":"HTTP连接结束";
  }catch(Exception e){if(rec==null)rec=Records.add("代理连接异常");rec.status="错误："+e.getMessage();}
  finally{sockets.remove(upstream);try{upstream.close();}catch(IOException ignored){}}
 }
 private void pump(InputStream in,OutputStream out,Records.Entry rec,boolean req,boolean inspect)throws IOException{
  byte[] b=new byte[8192];int n;while(!stopped&&(n=in.read(b))!=-1){out.write(b,0,n);out.flush();if(req)rec.up+=n;else rec.down+=n;if(inspect)rec.append(req,b,n);}
 }
 @Override public void close(){stopped=true;try{if(server!=null)server.close();}catch(IOException ignored){}for(Socket s:sockets)try{s.close();}catch(IOException ignored){}workers.shutdownNow();}
}
