package cn.laoya.capture;
import android.app.*;import android.content.*;import android.os.*;import cn.laoya.capture.pro.*;import java.io.*;
/** Manual loopback proxy. Does not establish a VPN. */
public class ProxyService extends Service {
 public static volatile Engine active;
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i==null||"STOP".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}
  if(Model.running)return START_NOT_STICKY;
  getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("manual","手动代理",NotificationManager.IMPORTANCE_LOW));
  PendingIntent stop=PendingIntent.getService(this,31,new Intent(this,ProxyService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);
  PendingIntent open=PendingIntent.getActivity(this,32,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
  startForeground(2,new Notification.Builder(this,"manual").setContentTitle("老鸭抓包 · 手动代理").setContentText("127.0.0.1:"+Model.manualPort+" · 未创建VPN").setSmallIcon(android.R.drawable.stat_sys_upload).setContentIntent(open).addAction(new Notification.Action.Builder(null,"停止",stop).build()).build());
  try{Model.directory=new File(getFilesDir(),"bodies");Model.directory.mkdirs();active=new Engine(s->true,new Rules(),Model.manualPort);active.start();Model.mode="manual";Model.proxyPort=active.port();Model.running=true;Model.state="手动代理监听中 · 不创建VPN";}catch(Exception e){Model.state="启动失败："+e.getMessage();stopSelf();}
  return START_NOT_STICKY;
 }
 @Override public void onDestroy(){DevJobs.stopAll();Engine p=active;active=null;if(p!=null)p.close();Model.proxyPort=0;Model.running=false;Model.stopBatch=true;Model.releaseAll();Overlay.hide();if(!Model.state.startsWith("启动失败"))Model.state="手动代理已停止";stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
