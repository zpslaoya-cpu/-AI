/* Pure aggregation logic, independently testable with Node.js. Amounts stored in minor units. */
(function(root,factory){const lib=factory();if(typeof module==='object'&&module.exports)module.exports=lib;else root.DuckReport=lib;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
function dateRange(from,to){if(!/^\d{4}-\d{2}-\d{2}$/.test(from)||!/^\d{4}-\d{2}-\d{2}$/.test(to)||from>to)return false;let a=new Date(from+'T12:00:00'),b=new Date(to+'T12:00:00');return Number.isFinite(+a)&&Number.isFinite(+b)&&(b-a)/86400000<=3660;}
function calculate(events,accounts,from,to,kind,uid){
 if(!dateRange(from,to))throw new Error('请输入有效的日期区间（最长 10 年）');
 const labels=Object.fromEntries((accounts||[]).map(a=>[a.uid,a.remark||a.uid]));
 const rows=new Map(),perDay=new Map();let successes=0, attempts=0, knownTotal=0, knownRecords=0;
 for(const x of events||[]){const day=String(x.created_at||'').slice(0,10);if(day<from||day>to||x.kind!==kind||(uid&&uid!==x.uid))continue;
  const key=day+'\u0000'+x.uid;
  if(!rows.has(key))rows.set(key,{date:day,uid:x.uid,remark:labels[x.uid]||x.uid,attempts:0,success:0,failure:0,unknown:0,known:0,amount:0});
  const r=rows.get(key);r.attempts++;attempts++;
  if(x.result==='success'){r.success++;successes++;}else if(x.result==='failure'){r.failure++;}else r.unknown++;
  if(x.result==='success'&&x.amount_minor!==null&&x.amount_minor!==undefined&&Number.isSafeInteger(Number(x.amount_minor))){r.amount+=Number(x.amount_minor);r.known++;knownRecords++;knownTotal+=Number(x.amount_minor);}
 }
 const detailed=[...rows.values()].sort((a,b)=>b.date.localeCompare(a.date)||a.remark.localeCompare(b.remark,'zh-CN'));
 for(const r of detailed){if(!perDay.has(r.date))perDay.set(r.date,{date:r.date,accounts:0,attempts:0,success:0,failure:0,unknown:0,known:0,amount:0});const d=perDay.get(r.date);d.accounts++;for(const k of ['attempts','success','failure','unknown','known','amount'])d[k]+=r[k];}
 const daily=[];
 // Include every calendar day in the selected interval, including zero-activity days.
 // UTC date arithmetic avoids local DST rollover problems.
 for(let day=new Date(from+'T00:00:00Z'),last=new Date(to+'T00:00:00Z');day<=last;day.setUTCDate(day.getUTCDate()+1)) {
  const key=day.toISOString().slice(0,10);
  daily.push(perDay.get(key)||{date:key,accounts:0,attempts:0,success:0,failure:0,unknown:0,known:0,amount:0});
 }
 daily.reverse();
 return {daily,detailed,attempts,successes,knownTotal,knownRecords,uniqueAccounts:new Set(detailed.map(x=>x.uid)).size};
}
function format(minor,kind){return kind==='coin'?String(minor): (minor/100).toFixed(2);}
function exportTxt(report,from,to,kind,uid){const lines=['🦆 老鸭喜马拉雅 · '+(kind==='coin'?'金币任务':'提现')+'日期区间统计','日期：'+from+' 至 '+to,'账号：'+(uid||'全部'),'数据说明：仅依据本机实际记录的结果，未记录的收益不能当作零。','', '【每日汇总】'];
for(const r of report.daily)lines.push(`${r.date} | 账号 ${r.accounts} | 执行 ${r.attempts} | 成功 ${r.success} | 失败 ${r.failure} | 待确认 ${r.unknown} | 已知金额 ${format(r.amount,kind)} | 有数量的成功记录 ${r.known}`);
lines.push('','【每号逐日明细】');for(const r of report.detailed)lines.push(`${r.date} | ${r.remark} (${r.uid}) | 执行 ${r.attempts} | 成功 ${r.success} | 失败 ${r.failure} | 待确认 ${r.unknown} | 已记录 ${format(r.amount,kind)} | 已确认收益条数 ${r.known}`);
lines.push('','总执行 '+report.attempts+'，总成功 '+report.successes+'，已记录总数量 '+format(report.knownTotal,kind),'导出时间 '+new Date().toLocaleString('zh-CN'));
return lines.join('\r\n')+'\r\n';}
return {dateRange,calculate,format,exportTxt};
});
