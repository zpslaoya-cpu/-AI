package cn.laoya.capture;
import java.io.*;import java.nio.charset.*;import java.util.*;import java.util.zip.*;
public class HttpTextTest {
 static final Charset L=StandardCharsets.ISO_8859_1;
 static void check(boolean x,String m){if(!x)throw new AssertionError(m);}
 static String msg(String extra,byte[] b){return "HTTP/1.1 200 OK\r\n"+extra+"\r\n"+new String(b,L);}
 static byte[] gzip(byte[] b)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();try(GZIPOutputStream g=new GZIPOutputStream(o)){g.write(b);}return o.toByteArray();}
 static byte[] deflate(byte[] b,boolean raw)throws Exception{Deflater d=new Deflater(6,raw);ByteArrayOutputStream o=new ByteArrayOutputStream();try(DeflaterOutputStream z=new DeflaterOutputStream(o,d)){z.write(b);}finally{d.end();}return o.toByteArray();}
 public static void main(String[] a)throws Exception{
  String html="<!doctype html><html><body>老鸭抓包：中文测试</body></html>";byte[] b=html.getBytes(StandardCharsets.UTF_8);
  check(HttpText.decode(msg("Content-Type: text/html; charset=utf-8\r\n",b),false).contains(html),"UTF8 HTML");
  String gb="<meta charset=gbk><p>中文页面</p>";
  check(HttpText.decode(msg("Content-Type: text/html\r\n",gb.getBytes("GBK")),false).contains(gb),"HTML meta GBK");
  byte[] gz=gzip(b);String chunk=Integer.toHexString(gz.length)+";test=1\r\n"+new String(gz,L)+"\r\n0\r\n\r\n";
  String h="Content-Type: text/html; charset=utf-8\r\nContent-Encoding: gzip\r\nTransfer-Encoding: chunked\r\n";
  check(HttpText.decode(msg(h,chunk.getBytes(L)),false).contains(html),"chunked gzip UTF8");
  for(boolean raw:new boolean[]{false,true})check(HttpText.decode(msg("Content-Type: text/html\r\nContent-Encoding: deflate\r\n",deflate(b,raw)),false).contains(html),"deflate "+raw);
  String broken="8\r\nabc";
  check(HttpText.decode(msg("Content-Type: text/plain\r\nTransfer-Encoding: chunked\r\n",broken.getBytes(L)),true).contains("abc"),"partial chunk");
  check(HttpText.decode(msg(h,Arrays.copyOf(chunk.getBytes(L),15)),true).contains("解压失败"),"partial gzip labeled");
  check(HttpText.decode(msg("Content-Type: image/png\r\n",new byte[]{0,1,2}),false).contains("二进制内容"),"binary labeled");
  check(HttpText.decode(msg("Content-Type: text/html\r\nContent-Encoding: br\r\n",b),false).contains("暂不支持"),"unsupported compression labeled");
  byte[] bomb=new byte[2*1024*1024+1];Arrays.fill(bomb,(byte)'a');check(HttpText.decode(msg("Content-Encoding: gzip\r\n",gzip(bomb)),false).contains("2MiB"),"decompression bound");
  System.out.println("PASS: UTF8 HTML, GBK meta, chunked gzip, zlib/raw deflate, incomplete bodies, binary, unsupported coding, 2MiB bound");
 }
}
