package cn.laoya.capture.pro;
import java.net.*;import java.io.*;import java.nio.charset.*;import java.nio.file.*;import java.util.*;import java.util.concurrent.*;
public class ProEngineTest {
 static final Charset L=StandardCharsets.ISO_8859_1;static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static byte[] request(String url,String body){byte[] b=body.getBytes(StandardCharsets.UTF_8);return ("POST "+url+" HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: "+b.length+"\r\n\r\n"+new String(b,L)).getBytes(L);}
 static String via(Engine p,String url,String body)throws Exception{try(Socket s=new Socket("127.0.0.1",p.port())){s.setSoTimeout(10000);s.getOutputStream().write(request(url,body));s.shutdownOutput();return new String(s.getInputStream().readAllBytes(),StandardCharsets.UTF_8);}}
 static void origin(ServerSocket o,String[] got){new Thread(()->{try(Socket s=o.accept()){BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));int len=0;String line;while(!(line=in.readLine()).isEmpty())if(line.toLowerCase().startsWith("content-length:"))len=Integer.parseInt(line.substring(15).trim());char[] body=new char[len];int n=in.read(body);got[0]=n>0?new String(body,0,n):"";byte[] bytes="{\"message\":\"原始中文\"}".getBytes(StandardCharsets.UTF_8);String head="HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n";s.getOutputStream().write(head.getBytes(L));s.getOutputStream().write((Integer.toHexString(bytes.length)+"\r\n").getBytes(L));s.getOutputStream().write(bytes);s.getOutputStream().write("\r\n0\r\n\r\n".getBytes(L));}catch(Exception e){throw new RuntimeException(e);}},"origin").start();}
 public static void main(String[] args)throws Exception {
  Model.directory=Files.createTempDirectory("laoya-bodies").toFile();Model.running=true;
  try(ServerSocket o=new ServerSocket(0,1,InetAddress.getLoopbackAddress());Engine p=new Engine(s->s.isBound()&&!s.isConnected(),(f,side)->{Model.Message m=side.equals("request")?f.request:f.response;Codec.edit(m,side.equals("request")?"{\"n\":20}":"{\"message\":\"修改中文\"}",Codec.rawHeaders(m),m.line);})){
   p.start();String[] got={null};origin(o,got);String result=via(p,"http://127.0.0.1:"+o.getLocalPort()+"/api","{\"n\":1}");check("{\"n\":20}".equals(got[0]),"request modification reached server");check(result.contains("修改中文"),"response modification reached client");check(!result.contains("Transfer-Encoding"),"chunked normalized");check(Model.snapshot().get(0).originalResponse.size>0,"original response saved");check(Files.size(Path.of(Model.snapshot().get(0).response.file))>0,"body file saved");
  }
  Model.clear();Model.requestBreak=true;
  try(Engine p=new Engine(s->true,(f,side)->{if(side.equals("request")){f.response=new Model.Message();f.response.line="HTTP/1.1 201 Mock";f.response.set("Content-Type","application/json");f.response.bytes("{\"mock\":true}".getBytes());f.note="模拟响应";}})){
   p.start();ExecutorService ex=Executors.newSingleThreadExecutor();Future<String> result=ex.submit(()->via(p,"http://does-not-exist.invalid/mock","{}"));long deadline=System.currentTimeMillis()+3000;while(Model.gates.isEmpty()&&System.currentTimeMillis()<deadline)Thread.sleep(10);check(!Model.gates.isEmpty(),"request breakpoint pauses");Model.Gate gate=Model.gates.values().iterator().next();gate.release(gate.message,false);check(result.get(5,TimeUnit.SECONDS).contains("mock"),"mock returns without server");ex.shutdownNow();
  }
  Model.requestBreak=false;Model.responseBreak=true;Model.clear();
  try(ServerSocket o=new ServerSocket(0,1,InetAddress.getLoopbackAddress());Engine p=new Engine(s->true,(f,side)->{})){
   p.start();String[] got={null};origin(o,got);ExecutorService ex=Executors.newSingleThreadExecutor();Future<String> result=ex.submit(()->via(p,"http://127.0.0.1:"+o.getLocalPort()+"/break","{}"));long deadline=System.currentTimeMillis()+3000;while(Model.gates.isEmpty()&&System.currentTimeMillis()<deadline)Thread.sleep(10);check(!Model.gates.isEmpty(),"response breakpoint pauses");Model.Gate g=Model.gates.values().iterator().next();check(g.side.equals("response"),"response gate direction");Codec.edit(g.message,"{\"edited\":true}",Codec.rawHeaders(g.message),"HTTP/1.1 202 Accepted");g.release(g.message,false);String res=result.get(5,TimeUnit.SECONDS);check(res.contains("202 Accepted")&&res.contains("edited"),"edited response release");ex.shutdownNow();
  }
  Model.responseBreak=false;
  try(Engine p=new Engine(s->true,(f,side)->{throw new IOException("blocked by test rule");})){p.start();check(via(p,"http://does-not-exist.invalid/block","{}").contains("502"),"blocked request visible failure");}
  System.out.println("PASS: real request/response modification, chunked decoding, body files, original message preservation, request/response gates, local mock without upstream, block error response");
 }
}
