# 老鸭抓包 0.2 — 代理实验工程

这是原生 Android Java 源码工程，不是 APK，不是已实测完成的通用 VPN 抓包器。

## 当前功能
选择已安装、可启动的 APP；申请系统 VPN 授权；在本机建立 HTTP 代理；HTTP 请求与响应原始字节的文本预览；HTTPS CONNECT 域名及双向字节统计；搜索、复制、系统文件选择器导出；前台通知停止。没有上传服务器。内存保留最近100个连接，每个方向文本最多64KiB，进程退出不保留。

## 必须知道的边界
- 用 VpnService.setHttpProxy 提供代理建议，没有默认路由，没有 TCP/IP 转发引擎。目标 APP 不遵循系统代理则无数据，不能宣称捕获所有流量。
- 不支持把 APK 放进虚拟容器执行。选择的是手机上已安装的 APP。
- HTTPS 只转发加密隧道，不展示加密请求/响应正文，不生成或安装 CA，不处理证书固定。
- HTTP 每条记录代表连接原始流；不是完整逐请求解析器。不解析 HTTP/2、WebSocket、gzip、分块或应用层二次加密。二进制按 ISO-8859-1 预览，中文可能乱码。仅 HTTP/1.x 代理可兼容；上游强制 Connection: close。
- 启动另一个 VPN 通常会替换当前 VPN。首版不支持常开 VPN/锁定模式。
- VPN界面在不同 Android 厂商系统上的代理继承行为需要手机验证。无记录不能判定为“目标APP没有联网”。

## 编译
在 Android Studio 打开根目录，使用 JDK17、Gradle8.9、Android SDK35、Android Gradle Plugin8.7.3，运行 `gradle :app:assembleDebug`。没有 Gradle wrapper 二进制，需本机安装 Gradle 或使用 Android Studio 配置的 Gradle。

也可以把根目录内容上传到你自己的 GitHub 仓库（包含 .github 目录），手动运行 Actions 的 Build Android APK。成功后下载 LaoyaCapture-debug-apk，解压安装 app-debug.apk。工作流未在此环境执行，首次远程构建可能需要调整。

## 使用
安装构建出的 APK → 选择 APP → 开始抓包并同意系统 VPN 弹窗 → 打开选中的 APP → 返回查看记录 → 停止抓包。导出只写入你在文件选择器选定的位置。

## 验证状态
本环境无 Android SDK/Gradle，未编译、未上机验证。对独立Java代理核心运行本地HTTP请求/响应和CONNECT隧道测试；Android生命周期和VPN兼容性仍需实机验证。详见 VALIDATION.txt。

## 后续真正通用版本需要
接入并审查成熟的用户态 TCP/IP 转发引擎，支持 DNS/UDP/IPv6 与连接归属；然后为愿意信任测试CA的自有/获授权测试APP加入HTTPS调试。不应把只读TUN而不转发的实现当成可用抓包器。

官方接口说明：https://developer.android.com/reference/android/net/VpnService.Builder#setHttpProxy(android.net.ProxyInfo)

## V0.2 修复
外连 Socket 先绑定本地临时端口，再调用 protect，最后 connect；解决V0.1中尚未初始化底层Socket就调用protect的错误。增加protect前已绑定、尚未连接的测试断言。未在安卓手机上验证该修复。
