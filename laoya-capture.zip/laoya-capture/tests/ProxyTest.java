package cn.laoya.capture;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;
public class ProxyTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception{
  try(ServerSocket origin=new ServerSocket(0,1,InetAddress.getLoopbackAddress());LocalProxy proxy=new LocalProxy(s->true)){
   proxy.start();
   Thread t=new Thread(()->{try(Socket s=origin.accept()){BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream()));String first=r.readLine();check(first.equals("POST /hello?q=1 HTTP/1.1"),first);String line;while(!(line=r.readLine()).isEmpty()){}char[] body=new char[4];check(r.read(body)==4,"body length");check(new String(body).equals("test"),"body");s.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nConnection: close\r\n\r\nhello".getBytes());}catch(Exception e){throw new RuntimeException(e);}});t.start();
   try(Socket c=new Socket("127.0.0.1",proxy.port())){c.setSoTimeout(5000);c.getOutputStream().write(("POST http://127.0.0.1:"+origin.getLocalPort()+"/hello?q=1 HTTP/1.1\r\nHost: localhost\r\nContent-Length: 4\r\n\r\ntest").getBytes());String result=new String(c.getInputStream().readAllBytes());check(result.endsWith("hello"),result);}
   t.join();Thread.sleep(50);check(Records.snapshot().get(0).detail().contains("hello"),"response logged");check(Records.snapshot().get(0).detail().contains("test"),"request body logged");
   Thread echo=new Thread(()->{try(Socket s=origin.accept()){byte[] b=s.getInputStream().readNBytes(4);s.getOutputStream().write(b);}catch(Exception e){throw new RuntimeException(e);}});echo.start();
   try(Socket c=new Socket("127.0.0.1",proxy.port())){c.setSoTimeout(5000);c.getOutputStream().write(("CONNECT 127.0.0.1:"+origin.getLocalPort()+" HTTP/1.1\r\nHost: localhost\r\n\r\n").getBytes());ByteArrayOutputStream h=new ByteArrayOutputStream();while(!h.toString().endsWith("\r\n\r\n"))h.write(c.getInputStream().read());check(h.toString().contains("200"),"CONNECT accepted");c.getOutputStream().write("ping".getBytes());check(new String(c.getInputStream().readNBytes(4)).equals("ping"),"tunnel echo");}
   echo.join();Thread.sleep(50);check(!Records.snapshot().get(0).detail().contains("ping"),"tunnel payload not logged");
   System.out.println("PASS: HTTP POST forwarding, response capture, CONNECT tunnel, no tunnel plaintext logging");
  }
 }
}
