package cn.laoya.capture;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;
import java.util.regex.*;
/** One explicit HTTP replay. Does not intercept or rewrite live traffic. */
public final class ReplayRequest {
 public final String method,url,body,contentType;
 private final List<String> headers;
 private final Charset charset;
 private ReplayRequest(String m,String u,String b,String ct,List<String> h,Charset c){method=m;url=u;body=b;contentType=ct;headers=h;charset=c;}
 public static ReplayRequest parse(String raw,boolean clipped)throws IOException{
  if(clipped)throw new IOException("请求被截断，无法安全重发");
  int end=raw.indexOf("\r\n\r\n");if(end<0)throw new IOException("请求尚未完整捕获");
  String[] h=raw.substring(0,end).split("\r\n");String[] first=h[0].split(" ",3);
  if(first.length!=3||!first[0].matches("[A-Z]+"))throw new IOException("请求行无效");
  if(first[0].equals("CONNECT"))throw new IOException("HTTPS正文未解密，不可编辑或重发");
  try{URI u=new URI(first[1]);if(!"http".equalsIgnoreCase(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getFragment()!=null)throw new Exception();}catch(Exception e){throw new IOException("仅支持已捕获的HTTP绝对地址");}
  String type="text/plain; charset=utf-8";long len=-1;List<String> list=new ArrayList<>();
  Set<String> remove=new HashSet<>(Arrays.asList("content-length","transfer-encoding","connection","proxy-connection","proxy-authorization","expect","trailer","upgrade","te","host"));
  for(int i=1;i<h.length;i++){int p=h[i].indexOf(':');if(p<1)throw new IOException("请求头格式错误");String k=h[i].substring(0,p).trim().toLowerCase(Locale.ROOT),v=h[i].substring(p+1).trim();
   if(k.equals("connection"))for(String token:v.split(","))remove.add(token.trim().toLowerCase(Locale.ROOT));
   if(k.equals("content-type"))type=v;
   if(k.equals("content-length")){if(len!=-1)throw new IOException("重复Content-Length");try{len=Long.parseLong(v);}catch(Exception e){throw new IOException("Content-Length无效");}if(len<0)throw new IOException("Content-Length无效");}
   if(k.equals("transfer-encoding"))throw new IOException("首版编辑暂不支持分块请求体");
   if(k.equals("content-encoding")&&!v.equalsIgnoreCase("identity"))throw new IOException("首版编辑暂不支持压缩请求体");
  }
  for(int i=1;i<h.length;i++){String k=h[i].substring(0,h[i].indexOf(':')).trim().toLowerCase(Locale.ROOT);if(!remove.contains(k))list.add(h[i]);}
  String lower=type.toLowerCase(Locale.ROOT);if(lower.contains("multipart/")||!(lower.startsWith("text/")||lower.contains("json")||lower.contains("xml")||lower.contains("x-www-form-urlencoded")))throw new IOException("当前编辑器仅支持文本/JSON/URL编码表单");
  byte[] b=raw.substring(end+4).getBytes(StandardCharsets.ISO_8859_1);
  if((len>=0&&len!=b.length)||(len<0&&b.length>0))throw new IOException("请求正文不完整或包含多条请求");
  Charset c=StandardCharsets.UTF_8;Matcher cm=Pattern.compile("charset\\s*=\\s*[\\\"']?([A-Za-z0-9._-]+)",Pattern.CASE_INSENSITIVE).matcher(type);
  if(cm.find())try{c=Charset.forName(cm.group(1));}catch(Exception e){throw new IOException("不支持的字符集");}
  try{return new ReplayRequest(first[0],first[1],c.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString(),type,list,c);}catch(CharacterCodingException e){throw new IOException("正文不是有效文本，不能用文本编辑器重发");}
 }
 public byte[] wire(String edited)throws IOException{
  byte[] b;
  try{ByteBuffer bb=charset.newEncoder().onUnmappableCharacter(CodingErrorAction.REPORT).encode(java.nio.CharBuffer.wrap(edited));b=new byte[bb.remaining()];bb.get(b);}catch(CharacterCodingException e){throw new IOException("修改内容无法用原字符集编码");}
  if(b.length>48*1024)throw new IOException("编辑后的正文上限48KiB");
  URI uri=URI.create(url);String host=uri.getRawAuthority();StringBuilder h=new StringBuilder(method+" "+url+" HTTP/1.1\r\nHost: "+host+"\r\n");
  for(String line:headers)h.append(line).append("\r\n");
  h.append("Content-Length: ").append(b.length).append("\r\nConnection: close\r\n\r\n");byte[] hb=h.toString().getBytes(StandardCharsets.ISO_8859_1);
  ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(hb);out.write(b);return out.toByteArray();
 }
}
