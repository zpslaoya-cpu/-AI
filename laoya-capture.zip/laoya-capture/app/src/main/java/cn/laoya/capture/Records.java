package cn.laoya.capture;
import java.util.*;
public final class Records {
 public static volatile boolean running=false;
 public static volatile String state="未启动";
 private static final LinkedList<Entry> entries=new LinkedList<>();
 public static class Entry {
  public final long time=System.currentTimeMillis();
  public final String title;
  public final StringBuilder request=new StringBuilder(),response=new StringBuilder();
  public volatile long up,down;
  public volatile String status="连接中";
  Entry(String t){title=t;}
  public synchronized void append(boolean req,byte[] b,int n){StringBuilder s=req?request:response;int left=65536-s.length(); if(left>0)s.append(new String(b,0,Math.min(left,n),java.nio.charset.StandardCharsets.ISO_8859_1));}
  public synchronized String detail(){return title+"\n"+status+"\n发送 "+up+" B / 接收 "+down+" B\n\n请求（最多64KiB）\n"+request+"\n\n响应（最多64KiB）\n"+response;}
 }
 public static synchronized Entry add(String title){Entry e=new Entry(title);entries.addFirst(e);while(entries.size()>100)entries.removeLast();return e;}
 public static synchronized List<Entry> snapshot(){return new ArrayList<>(entries);}
 public static synchronized void clear(){entries.clear();}
}
