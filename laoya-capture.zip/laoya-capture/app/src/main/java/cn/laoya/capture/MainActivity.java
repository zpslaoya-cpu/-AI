package cn.laoya.capture;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.VpnService;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
public class MainActivity extends Activity {
 private String selected="";
 private TextView status;
 private Button choose;
 private EditText search;
 private LinearLayout rows;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private String pendingExport;
 private final Runnable refresh=new Runnable(){public void run(){render();handler.postDelayed(this,1000);}};
 private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setPadding(12,10,12,10);return t;}
 private Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->action.run());return b;}
 @Override public void onCreate(Bundle b){super.onCreate(b);selected=getPreferences(0).getString("package","");
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(20,40,20,12);root.setBackgroundColor(Color.rgb(10,18,32));setContentView(root);
  root.addView(text("🦆 老鸭抓包",26));root.addView(text("代理实验版 · Android 10+",14));
  root.addView(text("HTTP：请求/响应原始流；HTTPS：域名/流量。部分APP忽略代理时无记录。仅本机处理，停止后立即断开。",14));
  choose=button(selected.isEmpty()?"选择要检测的APP":selected,this::pick);root.addView(choose);
  root.addView(button("开始抓包",()->{if(selected.isEmpty()){toast("请先选择APP");return;}Intent consent=VpnService.prepare(this);if(consent!=null)startActivityForResult(consent,10);else startCapture();}));
  root.addView(button("停止抓包",()->stopService(new Intent(this,CaptureService.class))));
  root.addView(button("打开选中的APP",()->{Intent i=getPackageManager().getLaunchIntentForPackage(selected);if(i!=null)startActivity(i);else toast("APP未安装或无法启动");}));
  LinearLayout tools=new LinearLayout(this);tools.addView(button("导出记录",this::export));tools.addView(button("清空",()->{Records.clear();render();}));root.addView(tools);
  status=text("",13);root.addView(status);search=new EditText(this);search.setSingleLine();search.setTextColor(Color.WHITE);search.setHintTextColor(Color.GRAY);search.setHint("搜索域名/请求地址");root.addView(search);
  ScrollView scroll=new ScrollView(this);rows=new LinearLayout(this);rows.setOrientation(1);scroll.addView(rows);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},20);
 }
 private void pick(){if(Records.running){toast("先停止抓包再换APP");return;}List<ResolveInfo> found=getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);TreeMap<String,String> apps=new TreeMap<>();for(ResolveInfo r:found){String pkg=r.activityInfo.packageName;if(!pkg.equals(getPackageName()))apps.put(r.loadLabel(getPackageManager())+" · "+pkg,pkg);}String[] names=apps.keySet().toArray(new String[0]);new AlertDialog.Builder(this).setTitle("选择APP（不需要重新安装APK）").setItems(names,(d,n)->{selected=apps.get(names[n]);getPreferences(0).edit().putString("package",selected).apply();choose.setText(names[n]);}).show();}
 private void startCapture(){startForegroundService(new Intent(this,CaptureService.class).putExtra("package",selected));}
 private void render(){status.setText(Records.state+" · 保留最近100条");rows.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.ROOT);for(Records.Entry e:Records.snapshot()){if(!e.title.toLowerCase(Locale.ROOT).contains(q))continue;TextView row=text(e.title+"\n"+e.status+" · ↑"+e.up+" ↓"+e.down,13);row.setOnClickListener(v->{TextView detail=text(e.detail(),13);detail.setTextIsSelectable(true);detail.setTextColor(Color.BLACK);ScrollView sv=new ScrollView(this);sv.addView(detail);new AlertDialog.Builder(this).setTitle("连接详情 · 原始文本").setView(sv).setPositiveButton("复制",(d,n)->{android.content.ClipboardManager cm=getSystemService(android.content.ClipboardManager.class);cm.setPrimaryClip(ClipData.newPlainText("抓包",e.detail()));}).setNegativeButton("关闭",null).show();});rows.addView(row);}}
 private void export(){StringBuilder b=new StringBuilder("老鸭抓包·代理实验版\n内容可能含登录凭据，请自行保管。二进制/压缩内容未解码。\n");for(Records.Entry e:Records.snapshot())b.append("\n----------------\n").append(e.detail());pendingExport=b.toString();startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/plain").putExtra(Intent.EXTRA_TITLE,"laoya-capture.txt"),11);}
 @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==10&&c==RESULT_OK)startCapture();if(r==11&&c==RESULT_OK&&data!=null&&pendingExport!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new IOException("无法打开文件");out.write(pendingExport.getBytes(StandardCharsets.UTF_8));toast("导出成功");}catch(Exception e){toast("导出失败："+e.getMessage());}pendingExport=null;}}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 @Override protected void onResume(){super.onResume();handler.post(refresh);}
 @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
}
