package cn.laoya.capture;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.net.VpnService;
import org.json.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 static final int BG=0xff050d18,PANEL=0xff0a1828,GREEN=0xff00efaa,CYAN=0xff39cbff,MUTED=0xff8ca9c0,WHITE=0xffe6f5ff,RED=0xffff5579,PURPLE=0xffbb7aff;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private String selected="",appName="选择目标 APP",section="监听台",filter="全部",screen="home",pendingExport;
 private boolean paused=false,fx=true,busy=false;
 private LinearLayout root,content,rows,metrics;private TextView status,countLabel,toggle;private EditText search;
 private ScrollView scroller;private Wave wave;private final float[] upload=new float[40],download=new float[40];
 private long lastUp,lastDown,lastTick;
 private String query="";
 private final Runnable refresh=new Runnable(){public void run(){if(screen.equals("home")){tick();if(!paused)renderRows();}handler.postDelayed(this,1000);}};
 private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
 private GradientDrawable box(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(12));d.setStroke(dp(1),stroke);return d;}
 private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
 private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(2),dp(4),dp(2),dp(4));return t;}
 private LinearLayout card(){LinearLayout l=col();l.setPadding(dp(12),dp(10),dp(12),dp(10));l.setBackground(box(PANEL,0xff18475d));return l;}
 private void add(LinearLayout parent,View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);parent.addView(v,p);}
 private void weight(LinearLayout l,View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(3),dp(2),dp(3),dp(2));l.addView(v,p);}
 private TextView button(String s,int color,Runnable action){TextView b=text(s,14,color);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(45));b.setPadding(dp(6),dp(12),dp(6),dp(12));b.setBackground(box(0xff0b1e2c,color));b.setOnClickListener(v->action.run());return b;}
 private void base(){root=col();root.setBackground(new CyberBackdrop());root.setPadding(dp(14),0,dp(14),dp(8));setContentView(root);root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(14),i.getSystemWindowInsetTop(),dp(14),Math.max(dp(8),i.getSystemWindowInsetBottom()));return i;});root.requestApplyInsets();getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);}
 @Override public void onCreate(Bundle b){super.onCreate(b);selected=getPreferences(0).getString("package","");appName=getPreferences(0).getString("appName","选择目标 APP");fx=getPreferences(0).getBoolean("fx",true);home();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},20);}
 private ImageView avatar(int size){ImageView iv=new ImageView(this);iv.setImageResource(cn.laoya.capture.R.drawable.brand);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setLayoutParams(new LinearLayout.LayoutParams(dp(size),dp(size)));iv.setBackground(box(PANEL,CYAN));iv.setClipToOutline(true);return iv;}
 private void home(){rows=null;metrics=null;wave=null;toggle=null;screen="home";base();LinearLayout header=row();header.addView(avatar(48));LinearLayout title=col();title.setPadding(dp(10),dp(4),0,dp(4));title.addView(text("老鸭抓包",25,WHITE));title.addView(text("CAPTURE · ANALYZE · REPLAY",10,CYAN));header.addView(title);add(root,header);
  status=text("",12,GREEN);add(root,status);
  scroller=new ScrollView(this);scroller.setFillViewport(true);content=col();scroller.addView(content);root.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
  if(section.equals("设置")){settings();}
  else if(section.equals("统计")){statistics();}
  else{
   if(section.equals("监听台")){metrics=row();add(content,metrics);wave=new Wave();add(content,wave);
    LinearLayout target=card();target.addView(text("◎ 目标应用 · 点击切换",11,CYAN));target.addView(text(appName,18,WHITE));target.addView(text(selected.isEmpty()?"仅检测选中的应用":selected,11,MUTED));target.setOnClickListener(v->pick());add(content,target);
    LinearLayout actions=row();toggle=button(Records.running?"■ 停止监听":"▶ 启动监听",GREEN,()->{if(Records.running)stopService(new Intent(this,CaptureService.class));else begin();});weight(actions,toggle);weight(actions,button("↗ 打开 APP",CYAN,this::openApp));add(content,actions);
   }
   LinearLayout tools=row();weight(tools,button(paused?"▶ 恢复列表":"Ⅱ 暂停列表",CYAN,()->{paused=!paused;home();}));weight(tools,button("⇧ 导出",CYAN,this::export));weight(tools,button("清空",RED,()->{Records.clear();lastUp=lastDown=0;Arrays.fill(upload,0);Arrays.fill(download,0);home();}));add(content,tools);
   search=new EditText(this);search.setSingleLine();search.setTextSize(13);search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setHint("搜索 URL、域名或关键词");search.setPadding(dp(12),dp(8),dp(12),dp(8));search.setBackground(box(PANEL,0xff18475d));search.setText(query);add(content,search);search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();renderRows();}public void afterTextChanged(Editable e){}});
   LinearLayout filters=row();for(String f:new String[]{"全部","HTTP","HTTPS","错误"})weight(filters,button(f,f.equals(filter)?GREEN:MUTED,()->{filter=f;home();}));add(content,filters);
   countLabel=text("",11,MUTED);add(content,countLabel);rows=col();add(content,rows);renderRows();
   add(content,text("HTTPS 正文未解密 · 仅支持遵循系统代理的应用\n点击 HTTP 记录，可查看正文并手动编辑重发",11,MUTED));
  }
  LinearLayout nav=row();for(String n:new String[]{"监听台","记录","统计","设置"})weight(nav,button(n,section.equals(n)?GREEN:MUTED,()->{section=n;home();}));add(root,nav);tick();
 }
 private long[] totals(){long u=0,d=0,active=0;for(Records.Entry e:Records.snapshot()){u+=e.up;d+=e.down;if(e.ended==0)active++;}return new long[]{u,d,active};}
 private static String size(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.ROOT,"%.1f KB",b/1024.0);return String.format(Locale.ROOT,"%.2f MB",b/1048576.0);}
 private void tick(){long[] t=totals();long now=System.currentTimeMillis();if(lastTick>0&&now-lastTick>500){System.arraycopy(upload,1,upload,0,39);System.arraycopy(download,1,download,0,39);upload[39]=Math.max(0,t[0]-lastUp)*1000f/(now-lastTick);download[39]=Math.max(0,t[1]-lastDown)*1000f/(now-lastTick);}lastTick=now;lastUp=t[0];lastDown=t[1];
  if(toggle!=null)toggle.setText(Records.running?"■ 停止监听":"▶ 启动监听");
  if(status!=null)status.setText((Records.running?"● 正在监听":"○ 监听已停止")+"  /  V0.4 CYBER\n"+Records.state);
  if(metrics!=null&&section.equals("监听台")){metrics.removeAllViews();String[] values={""+Records.snapshot().size(),size(t[0]),size(t[1]),""+t[2]};String[] names={"连接记录","发送","接收","活跃"};for(int i=0;i<4;i++){LinearLayout c=card();c.setPadding(dp(6),dp(8),dp(6),dp(8));c.addView(text(values[i],16,i%2==0?CYAN:GREEN));c.addView(text(names[i],10,MUTED));weight(metrics,c);}if(wave!=null)wave.invalidate();}
 }
 private void renderRows(){if(rows==null||!screen.equals("home"))return;rows.removeAllViews();int count=0;for(Records.Entry e:Records.snapshot()){
  if(!query.isEmpty()&&!e.title.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)))continue;
  if(filter.equals("HTTP")&&e.encrypted()||filter.equals("HTTPS")&&!e.encrypted()||filter.equals("错误")&&!e.failed())continue;
  count++;LinearLayout c=card();int color=e.failed()?RED:e.encrypted()?CYAN:e.title.startsWith("POST ")?PURPLE:GREEN;
  TextView title=text(e.title,13,color);title.setTypeface(Typeface.MONOSPACE);title.setMaxLines(3);c.addView(title);
  int code=e.code();c.addView(text((code>0?"HTTP "+code+" · ":"")+e.status,11,e.failed()?RED:MUTED));
  c.addView(text(new java.text.SimpleDateFormat("HH:mm:ss",Locale.ROOT).format(new Date(e.time))+"  ↑"+size(e.up)+"  ↓"+size(e.down)+(e.ended>0?"  "+(e.ended-e.time)+" ms":""),10,MUTED));c.setOnClickListener(v->detail(e,"请求"));add(rows,c);
  }
  if(count==0)add(rows,text("⌁ 暂无匹配记录\n开始监听并在目标 APP 中操作后查看",14,MUTED));
  if(countLabel!=null)countLabel.setText("显示 "+count+" 条 / 最近100个连接 · "+(paused?"列表已暂停，采集继续":"实时更新"));
 }
 private void subheader(String title,Runnable back){LinearLayout r=row();r.addView(button("‹ 返回",CYAN,back));TextView t=text(title,20,WHITE);t.setPadding(dp(14),0,0,0);r.addView(t);add(root,r);}
 private void detail(Records.Entry e,String tab){screen="detail";base();subheader("连接详情",this::home);add(root,text(e.title,14,CYAN));LinearLayout tabs=row();for(String n:new String[]{"请求","响应","概览"})weight(tabs,button(n,n.equals(tab)?GREEN:MUTED,()->detail(e,n)));add(root,tabs);
  String s=tab.equals("请求")?e.requestText():tab.equals("响应")?e.responseText():e.detail();
  ScrollView vertical=new ScrollView(this);HorizontalScrollView horizontal=new HorizontalScrollView(this);TextView body=text(s,12,WHITE);body.setTypeface(Typeface.MONOSPACE);body.setTextIsSelectable(true);body.setPadding(dp(12),dp(12),dp(12),dp(12));body.setBackground(box(PANEL,0xff18475d));horizontal.addView(body);vertical.addView(horizontal);root.addView(vertical,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout actions=row();weight(actions,button("复制当前",CYAN,()->copy(s)));weight(actions,button("修改请求体",GREEN,()->{try{editor(e,e.editable());}catch(IOException ex){toast(ex.getMessage());}}));add(root,actions);
 }
 private Object json(String s)throws JSONException {String t=s.trim();JSONTokener tokener=new JSONTokener(t);Object o=tokener.nextValue();if(tokener.nextClean()!=0)throw new JSONException("JSON后面存在多余内容");if(!(o instanceof JSONObject)&&!(o instanceof JSONArray))throw new JSONException("请输入JSON对象或数组");if(o instanceof JSONObject)new JSONObject(t);else new JSONArray(t);return o;}
 private void editor(Records.Entry e,ReplayRequest req){screen="editor";base();subheader("请求体编辑器",()->detail(e,"请求"));add(root,text(req.method+" · "+req.url,13,CYAN));add(root,text("● 草稿未发送 · 仅手动重发本次",12,PURPLE));
  LinearLayout modes=row();String initial=req.contentType.contains("json")?"JSON":req.contentType.contains("x-www-form-urlencoded")?"表单":"原始文本";final String[] mode={initial};for(String m:new String[]{"JSON","原始文本","表单"})weight(modes,button(m,CYAN,()->{mode[0]=m;toast(m.equals("表单")?"表单使用 key=value&key2=value2 URL编码格式":"编辑模式："+m);}));add(root,modes);
  add(root,text("原 Content-Type："+req.contentType+"\n切换编辑模式不会修改请求头",10,MUTED));
  EditText edit=new EditText(this);edit.setTextColor(GREEN);edit.setHintTextColor(MUTED);edit.setHint("输入请求正文");edit.setGravity(Gravity.TOP);edit.setTextSize(14);edit.setTypeface(Typeface.MONOSPACE);edit.setBackground(box(PANEL,CYAN));edit.setPadding(dp(12),dp(12),dp(12),dp(12));edit.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);edit.setText(req.body);root.addView(edit,new LinearLayout.LayoutParams(-1,0,1));
  TextView diff=text("",11,MUTED);add(root,diff);edit.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){diff.setText("原文 "+req.body.length()+" 字符 → "+s.length()+" 字符 · "+(req.body.contentEquals(s)?"未修改":"已修改，尚未发送"));}public void afterTextChanged(Editable x){}});
  LinearLayout tools=row();weight(tools,button("格式化 JSON",CYAN,()->{try{Object o=json(edit.getText().toString());edit.setText(o instanceof JSONObject?((JSONObject)o).toString(2):((JSONArray)o).toString(2));mode[0]="JSON";}catch(Exception ex){toast("JSON格式错误："+ex.getMessage());}}));weight(tools,button("校验",CYAN,()->{try{if(mode[0].equals("JSON"))json(edit.getText().toString());else if(mode[0].equals("表单"))for(String part:edit.getText().toString().split("&"))java.net.URLDecoder.decode(part,"UTF-8");req.wire(edit.getText().toString());toast("校验通过");}catch(Exception ex){toast(ex.getMessage());}}));weight(tools,button("修改对比",PURPLE,()->{TextView t=text("原始正文\n"+req.body+"\n\n修改后\n"+edit.getText(),13,WHITE);t.setTextIsSelectable(true);ScrollView sv=new ScrollView(this);sv.setBackgroundColor(BG);sv.addView(t);new AlertDialog.Builder(this).setTitle("修改对比").setView(sv).setPositiveButton("关闭",null).show();}));add(root,tools);
  add(root,text("重发会向原地址额外发送一次真实请求；不会修改后续请求。\nHTTPS未解密、压缩或分块请求体暂不支持。",11,MUTED));
  LinearLayout actions=row();weight(actions,button("恢复原始",CYAN,()->edit.setText(req.body)));TextView send=button("➤ 应用并重发",GREEN,()->{if(busy){toast("上一条重发还在处理中");return;}if(!Records.running){toast("请先返回监听台启动监听");return;}try{String body=edit.getText().toString();if(mode[0].equals("JSON"))json(body);byte[] bytes=req.wire(body);busy=true;toast("已提交重发，请稍候");new Thread(()->{String result;try{CaptureService.replay(bytes);result="重发结束，结果已记录；请查看响应状态";}catch(Exception ex){result="重发失败："+ex.getMessage();}String msg=result;handler.post(()->{busy=false;toast(msg);});},"laoya-replay").start();}catch(Exception ex){toast(ex.getMessage());}});weight(actions,send);add(root,actions);
 }
 private void statistics(){LinearLayout c=card();int http=0,tls=0,errors=0;TreeMap<String,Integer> domains=new TreeMap<>();for(Records.Entry e:Records.snapshot()){if(e.encrypted())tls++;else http++;if(e.failed())errors++;try{String url=e.title.substring(e.title.indexOf(' ')+1);String host=e.encrypted()?url:java.net.URI.create(url).getHost();if(host!=null)domains.put(host,domains.getOrDefault(host,0)+1);}catch(Exception ignored){}}long[] t=totals();c.addView(text("SESSION ANALYTICS",14,CYAN));c.addView(text("HTTP "+http+"   HTTPS "+tls+"   错误 "+errors,18,WHITE));c.addView(text("发送 "+size(t[0])+"  /  接收 "+size(t[1]),14,GREEN));c.addView(text("统计口径：当前保留的最近100个连接；连接不是请求数量。\n进程结束不保留记录。",11,MUTED));add(content,c);for(Map.Entry<String,Integer> e:domains.entrySet()){LinearLayout d=card();d.addView(text(e.getKey(),14,CYAN));d.addView(text(e.getValue()+" 个连接",12,MUTED));add(content,d);}}
 private void settings(){LinearLayout c=card();c.addView(avatar(88));c.addView(text("老鸭抓包 · V0.4 CYBER",21,GREEN));c.addView(text("你的原图已用于桌面图标和应用头像",12,MUTED));Switch animations=new Switch(this);animations.setText("流量图发光特效");animations.setTextColor(WHITE);animations.setChecked(fx);animations.setOnCheckedChangeListener((b,on)->{fx=on;getPreferences(0).edit().putBoolean("fx",on).apply();});c.addView(animations);c.addView(text("功能范围\n• HTTP原始头与解码正文\n• UTF-8/GBK、gzip/deflate、chunked解码\n• 文本请求体编辑与单次手动重发\n• 真实连接统计和流量波形\n• HTTPS仅加密隧道，不解密正文\n• 暂无自动修改规则、虚拟容器\n\n数据\n• 仅本机处理，无上传服务器\n• 最近100个连接，每方向64KiB\n• 重发保留原始请求中的Cookie等头部\n• 导出可能包含登录凭据，请自行保管\n\n系统限制\n• 部分应用忽略系统代理则无法采集\n• 无默认路由和通用TCP/IP转发引擎\n• 同时只能使用一个系统VPN",13,MUTED));add(content,c);}
 private void begin(){if(selected.isEmpty()){pick();return;}Intent consent=VpnService.prepare(this);if(consent!=null)startActivityForResult(consent,10);else startCapture();}
 private void startCapture(){startForegroundService(new Intent(this,CaptureService.class).putExtra("package",selected));handler.postDelayed(()->{if(screen.equals("home"))home();},600);}
 private void openApp(){Intent i=getPackageManager().getLaunchIntentForPackage(selected);if(i!=null)startActivity(i);else toast("先选择可启动的APP");}
 private void pick(){if(Records.running){toast("先停止监听再切换APP");return;}List<ResolveInfo> found=getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);TreeMap<String,String> apps=new TreeMap<>();for(ResolveInfo r:found){String pkg=r.activityInfo.packageName;if(!pkg.equals(getPackageName()))apps.put(r.loadLabel(getPackageManager())+" · "+pkg,pkg);}String[] names=apps.keySet().toArray(new String[0]);new AlertDialog.Builder(this).setTitle("选择目标应用").setItems(names,(d,n)->{selected=apps.get(names[n]);appName=names[n].split(" · ")[0];getPreferences(0).edit().putString("package",selected).putString("appName",appName).apply();home();}).show();}
 private void export(){StringBuilder b=new StringBuilder("老鸭抓包 V0.4\n当前保留的连接记录，可能含登录凭据。\n");for(Records.Entry e:Records.snapshot())b.append("\n----------------\n").append(e.detail());pendingExport=b.toString();startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/plain").putExtra(Intent.EXTRA_TITLE,"laoya-capture.txt"),11);}
 @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==10&&c==RESULT_OK)startCapture();if(r==11){if(c==RESULT_OK&&data!=null&&pendingExport!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new IOException("无法打开文件");out.write(pendingExport.getBytes(StandardCharsets.UTF_8));toast("导出成功");}catch(Exception e){toast("导出失败："+e.getMessage());}}pendingExport=null;}}
 private void copy(String s){getSystemService(android.content.ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("抓包",s));toast("已复制");}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 @Override public void onBackPressed(){if(!screen.equals("home")){home();return;}super.onBackPressed();}
 @Override protected void onResume(){super.onResume();handler.removeCallbacks(refresh);handler.post(refresh);}
 @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
 private class CyberBackdrop extends android.graphics.drawable.Drawable {
  private final Paint p=new Paint(3);
  @Override public void draw(Canvas c){android.graphics.Rect b=getBounds();c.drawColor(BG);p.setStrokeWidth(dp(.5f));p.setColor(0xff0b2130);int step=dp(24);for(int x=0;x<b.width();x+=step)c.drawLine(x,0,x,b.height(),p);for(int y=0;y<b.height();y+=step)c.drawLine(0,y,b.width(),y,p);p.setColor(0xff15536a);p.setStrokeWidth(dp(1));c.drawLine(dp(2),dp(8),dp(2),b.height()-dp(8),p);c.drawLine(b.width()-dp(2),dp(8),b.width()-dp(2),b.height()-dp(8),p);p.setColor(CYAN);c.drawLine(dp(2),dp(8),dp(30),dp(8),p);c.drawLine(b.width()-dp(30),b.height()-dp(8),b.width()-dp(2),b.height()-dp(8),p);}
  @Override public void setAlpha(int a){} @Override public void setColorFilter(ColorFilter f){} @Override public int getOpacity(){return PixelFormat.OPAQUE;}
 }
 private class Wave extends View {
  private final Paint p=new Paint(3);
  Wave(){super(MainActivity.this);setLayoutParams(new LinearLayout.LayoutParams(-1,dp(148)));setBackground(box(PANEL,0xff18475d));setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),left=dp(12),top=dp(38),bottom=h-dp(20);p.setTextSize(dp(11));p.setColor(CYAN);p.setStyle(Paint.Style.FILL);c.drawText("实时流量  /  最近40次采样",left,dp(20),p);p.setColor(0xff153448);p.setStrokeWidth(dp(.6f));for(int i=0;i<=8;i++)c.drawLine(left+i*(w-2*left)/8,top,left+i*(w-2*left)/8,bottom,p);for(int i=0;i<=3;i++)c.drawLine(left,top+i*(bottom-top)/3,w-left,top+i*(bottom-top)/3,p);float max=1;for(float x:upload)max=Math.max(max,x);for(float x:download)max=Math.max(max,x);float[][] arrays={upload,download};int[] colors={CYAN,GREEN};for(int j=0;j<2;j++){Path path=new Path();for(int i=0;i<40;i++){float x=left+(w-left*2)*i/39,y=bottom-arrays[j][i]/max*(bottom-top);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}p.setColor(colors[j]);p.setStrokeWidth(dp(1.6f));p.setStyle(Paint.Style.STROKE);if(fx)p.setShadowLayer(dp(5),0,0,colors[j]);c.drawPath(path,p);p.clearShadowLayer();}p.setStyle(Paint.Style.FILL);p.setColor(MUTED);p.setTextSize(dp(9));c.drawText("↑ "+size((long)upload[39])+"/s    ↓ "+size((long)download[39])+"/s",left,h-dp(6),p);}
 }
}
