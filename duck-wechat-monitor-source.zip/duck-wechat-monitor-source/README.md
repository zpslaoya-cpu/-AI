# 🦆 老鸭公众号更新监控 Android APP V1.0

本项目是一套 Android 原生外壳（Java + WebView UI + SQLite 数据持久化 + JobScheduler 检测任务），支持手机直接安装。**本版本使用本地数据库**；目录 `docs/supabase-schema.sql` 是未来云端同步的结构设计，尚未部署云项目。

## 当前已实现

- 原生安卓 APP（最低 Android 8.0 / API 26）；深色赛博风移动 UI，适配窄屏。
- 批量添加公众号（每行 `名称,原始ID`）、名称 ID 成对去重、暂停、启用、删除。
- 文章手动录入（HTTPS 链接）、基于微信 `__biz+mid+idx` 或规范化链接的 SHA-256 去重。
- SQLite 本地存储、文章查询/按公众号与日期筛选、按日期归档、当日文章计数。
- 配置自有/授权文章来源 HTTPS 接口，并在 APP 内立即发起检测，持久化成功/失败/限流日志。
- Android JobScheduler 定时检查（约 30 分钟触发一次，每个账号间隔至少 120 分钟；系统可能延迟甚至跳过，非 24x7 SLA）。
- 导出为 JSON 分享文本。可从手机浏览器外部打开原始文章。
- `docs/` 有 Supabase 数据库 SQL 和示例 feed 契约。

## 尚未完成/不应误解

- 未接入公众号的通用文章数据供应商；微信不向所有用户开放任意公众号公开历史抓取 API。不填文章来源时，APP 不会自动获得文章，也不会虚构数据。
- 未创建 Supabase 云项目，云端备份、跨设备同步、云端持续定时监控、账号密码登录、真正的系统推送通知**尚未接入**。
- 获取最新文章依赖你配置的合法 HTTPS JSON 接口。接口应识别 `{id}` 这个原始 ID 或 `{name}` 公众号名称。
- 本地归档最多加载最近 1500 篇用于 UI，旧文章仍留在数据库，后续应增加分页。导出范围为当前 snapshot 内记录。

## 数据源契约

假设你的接口 URL 是 `https://your-source.example/api/articles?account={id}`，进入 APP 设置粘贴该模板。服务端应返回：

```json
{
  "articles": [
    { "title": "文章标题", "url": "https://mp.weixin.qq.com/s?...", "published_at": "2026-10-24" }
  ]
}
```

检测上限每个账号每轮 200 篇，单次响应不超过 2MB。HTTP 429 单独标记限流；其他请求错误作为失败写日志，而不是当作没有更新。

## GitHub Actions 自动编译 APK

把此目录完整上传到自己的 GitHub 仓库子目录 `wechat-monitor-app/`，将 `.github/workflows/build-apk.yml` 放到**仓库根目录** `.github/workflows/wechat-monitor-apk.yml`。GitHub 里打开 **Actions → Build WeChat Monitor APK → Run workflow**，完成后在 Artifacts 下载 `Duck-WeChat-Monitor-APK`，解压得到 `app-debug.apk`，在安卓手机安装。

也可以在 Android Studio 打开这个工程，安装 Android SDK 35 + JDK17，执行：

```bash
gradle :app:assembleDebug
```

AGP 8.7.3 / Gradle 8.9 / Java 17 / Android SDK 35。首次构建需要互联网下载 Gradle 与依赖。本版本使用默认 debug 签名，仅供个人测试，正式分发需要配置正式签名与版本管理。

## 后续云端路线

1. 创建 Supabase 项目，运行 `docs/supabase-schema.sql`。
2. 开发登录、帐号订阅、文章同步的 Edge Functions/RLS API。
3. 接入合法文章来源、执行定时 Cron 检测和幂等入库。
4. APP 升级为云端首页/离线缓存双模式，接入推送服务。

## 安全注意

不可在 Android APK、网页、公共 GitHub 存放 Supabase secret / service_role key、供应商私密 Token。文中的 HTTPS 模板只适合无需长期密钥放在客户端的授权 Feed；需要密钥的场景必须加服务端代理。对外部链接仅允许 HTTPS。公开仓库请勿提交用户隐私或真实监控凭据。
