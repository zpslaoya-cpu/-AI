const assert=require('assert');const r=require('../app/src/main/assets/report.js');
const accounts=[{uid:'111',remark:'鸭01'},{uid:'222',remark:'鸭02'}];
const events=[
 {uid:'111',created_at:'2026-10-26 08:00:00',kind:'coin',result:'success',amount_minor:150},
 {uid:'111',created_at:'2026-10-26 08:10:00',kind:'coin',result:'success',amount_minor:null},
 {uid:'111',created_at:'2026-10-26 08:20:00',kind:'coin',result:'failure',amount_minor:null},
 {uid:'222',created_at:'2026-10-26 09:00:00',kind:'coin',result:'success',amount_minor:33},
 {uid:'222',created_at:'2026-10-27 09:00:00',kind:'withdraw',result:'success',amount_minor:220},
 {uid:'222',created_at:'2026-10-27 09:10:00',kind:'withdraw',result:'unknown',amount_minor:null}
];
const x=r.calculate(events,accounts,'2026-10-26','2026-10-27','coin','');
assert.equal(x.attempts,4);assert.equal(x.successes,3);assert.equal(x.knownTotal,183);assert.equal(x.knownRecords,2);assert.equal(x.daily.length,2);assert.equal(x.uniqueAccounts,2);assert.equal(x.detailed.length,2);
assert.equal(x.detailed.find(a=>a.uid==='111').attempts,3);assert.equal(x.detailed.find(a=>a.uid==='111').known,1);
assert.ok(r.exportTxt(x,'2026-10-26','2026-10-27','coin','').includes('鸭01'));
const y=r.calculate(events,accounts,'2026-10-26','2026-10-27','withdraw','222');
assert.equal(y.attempts,2);assert.equal(y.knownTotal,220);assert.equal(r.format(y.knownTotal,'withdraw'),'2.20');
assert.equal(x.daily.find(a=>a.date==='2026-10-27').attempts,0);
assert.equal(r.dateRange('2026-10-28','2026-10-27'),false);assert.equal(r.dateRange('2026-10-27','2026-10-27'),true);
console.log('PASS: stats, date validation, multi-run, nullable rewards, TXT, filtering');
