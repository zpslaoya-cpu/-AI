from playwright.sync_api import sync_playwright
from pathlib import Path
import os, threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
root=Path(__file__).resolve().parents[1]
os.chdir(str(root/'app/src/main/assets'))
server=ThreadingHTTPServer(('127.0.0.1',0),SimpleHTTPRequestHandler)
threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--allow-file-access-from-files'])
 page=browser.new_page(viewport={'width':412,'height':891},device_scale_factor=1)
 mockScript='''
 (function(){let accounts=[],events=[],logs=[];const now=()=>new Date().toISOString().slice(0,10)+' 12:00:00';window.__mock={get accounts(){return accounts;},get events(){return events;},get logs(){return logs;}};
 window.DuckNative={
 snapshot:()=>JSON.stringify({accounts,events,logs}),
 account:(uid,remark)=>{uid=uid.trim();if(!uid)return JSON.stringify({ok:false,message:'uid required'});let row=accounts.find(x=>x.uid===uid);if(row)row.remark=remark;else accounts.push({uid,remark,created_at:now()});logs.unshift({level:'INFO',message:'Saved '+uid,created_at:now()});return JSON.stringify({ok:true,message:'saved'});},
 removeAccount:uid=>{accounts=accounts.filter(x=>x.uid!==uid);return JSON.stringify({ok:true,message:'removed'});},
 importAccounts:input=>{for(const line of input.trim().split(/\\n/)){const [uid,remark]=line.split(',');if(!accounts.some(x=>x.uid===uid))accounts.push({uid,remark:remark||'',created_at:now()});}return JSON.stringify({ok:true,message:'imported'});},
 record:(uid,kind,result,amount,note)=>{events.unshift({uid,kind,result,amount_minor:amount?kind==='withdraw'?Math.round(Number(amount)*100):Number(amount):null,note,created_at:now()});logs.unshift({level:'SUCCESS',message:'Saved record '+uid,created_at:now()});return JSON.stringify({ok:true,message:'recorded'});},
 exportTxt:(name,body)=>{window.__export={name,body};},
 openGroup:()=>{window.__openGroup=true;},
 pickLegacyAccounts:()=>{window.__legacyOpened=true;}
 };})();'''
 page.evaluate(mockScript)

 page.evaluate("Object.defineProperty(window, 'localStorage', {value: { data: {}, getItem(k){return this.data[k]??null},setItem(k,v){this.data[k]=v},removeItem(k){delete this.data[k]} }, configurable:true})")
 html=(root/'app/src/main/assets/index.html').read_text()
 for js in ('report.js','app.js'):
   html=html.replace('<script src="'+js+'"></script>', '<script>'+(root/'app/src/main/assets'/js).read_text()+'</script>')
 page.set_content(html)

 page.wait_for_timeout(900)
 assert page.locator('h1').inner_text()=='老鸭喜马拉雅'
 assert page.locator('#page-home.active').count()==1
 page.locator('nav [data-page=accounts]').click()
 page.get_by_role('button',name='选择 xmly_accounts.json 导入').click()
 assert page.evaluate('window.__legacyOpened===true')
 page.evaluate('window.DuckApp.legacyResult(JSON.stringify({ok:true,message:"已完成测试导入"}))')
 assert '已完成测试导入' in page.locator('#legacyStatus').inner_text()
 page.locator('#uidInput').fill('100001')
 page.locator('#remarkInput').fill('老鸭01')
 page.get_by_role('button',name='保存账号').click()
 assert page.get_by_text('老鸭01').count()>=1
 page.locator('nav [data-page=record]').click()
 page.locator('#eventAmount').fill('150')
 page.get_by_role('button',name='保存执行记录').click()
 page.locator('#eventAmount').fill('200')
 page.get_by_role('button',name='保存执行记录').click()
 page.locator('nav [data-page=stats]').click()
 assert page.locator('#statsKpis').get_by_text('350').count()>=1
 assert page.locator('#statsKpis').get_by_text('2').count()>=1
 page.get_by_role('button',name='一键导出 TXT').click()
 assert '350' in page.evaluate('window.__export.body')
 page.get_by_role('button',name='每号逐日明细').click()
 assert '100001' in page.locator('#statsBody').inner_text()
 page.locator('nav [data-page=logs]').click()
 assert 'Saved record' in page.locator('#logList').inner_text()
 page.locator('nav [data-page=settings]').click()
 page.get_by_role('button',name='打开 QQ 群邀请链接').click()
 assert page.evaluate('window.__openGroup===true')
 page.screenshot(path='/mnt/data/老鸭喜马拉雅_Android_V1_1界面预览.png',full_page=True)
 print('PASS UI: legacy import picker and callback, account add, repeat record, range stats, TXT, detail, logs, navigation, group')
 browser.close()
