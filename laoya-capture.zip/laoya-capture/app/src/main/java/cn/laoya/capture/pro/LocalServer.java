package cn.laoya.capture.pro;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;
public final class LocalServer implements AutoCloseable {
 private ServerSocket server;private volatile boolean closed;public volatile String body="{\"message\":\"老鸭本机测试\",\"ok\":true}",type="application/json; charset=utf-8";public volatile int status=200;
 public int start()throws IOException {server=new ServerSocket(0,16,InetAddress.getByName("127.0.0.1"));new Thread(()->{while(!closed)try{Socket c=server.accept();new Thread(()->{try(Socket s=c){s.setSoTimeout(5000);InputStream in=s.getInputStream();int state=0,n=0;while(n++<65536){int b=in.read();if(b<0)break;state=b==new int[]{13,10,13,10}[state]?state+1:(b==13?1:0);if(state==4)break;}byte[] bytes=body.getBytes(StandardCharsets.UTF_8);s.getOutputStream().write(("HTTP/1.1 "+status+" Local\r\nContent-Type: "+type+"\r\nContent-Length: "+bytes.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));s.getOutputStream().write(bytes);}catch(Exception ignored){}},"local-http-client").start();}catch(Exception ignored){}},"local-http").start();return server.getLocalPort();}
 public void close(){closed=true;try{server.close();}catch(Exception ignored){}}
}
