package cn.laoya.wechatmonitor;
import android.app.job.JobService;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobInfo;
import android.content.Context;
import android.content.ComponentName;

public class MonitorJobService extends JobService {
    private Thread worker;
    public static void schedule(Context context){
        try {
            JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            JobInfo info=new JobInfo.Builder(64021,new ComponentName(context,MonitorJobService.class))
                .setPeriodic(30*60*1000L,15*60*1000L)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .build();
            if(scheduler!=null)scheduler.schedule(info);
        }catch(Exception ignored){}
    }
    @Override public boolean onStartJob(JobParameters params){
        worker=new Thread(()->{MonitorEngine.run(getApplicationContext(),false,null);jobFinished(params,false);},"wechat-monitor-job");worker.start();return true;
    }
    @Override public boolean onStopJob(JobParameters params){return true;}
}
