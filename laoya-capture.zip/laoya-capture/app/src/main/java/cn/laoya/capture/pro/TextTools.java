package cn.laoya.capture.pro;
import java.util.*;import java.util.regex.*;import java.io.*;
public final class TextTools {
 public static class DeadlineText implements CharSequence {
  final String text;final int from,to;final long deadline;
  DeadlineText(String s,long deadline){this(s,0,s.length(),deadline);}DeadlineText(String s,int a,int b,long d){text=s;from=a;to=b;deadline=d;}
  void check(){if(System.nanoTime()>deadline||Thread.currentThread().isInterrupted())throw new IllegalArgumentException("正则超时（最多500ms），请缩短输入或简化表达式");}
  public int length(){check();return to-from;}public char charAt(int i){check();return text.charAt(from+i);}public CharSequence subSequence(int a,int b){check();return new DeadlineText(text,from+a,from+b,deadline);}public String toString(){check();return text.substring(from,to);}
 }
 public static List<String[]> extract(String pattern,String text){if(pattern.length()>256)throw new IllegalArgumentException("表达式最多256字符");if(text.length()>131072)throw new IllegalArgumentException("输入最多128Ki字符");ArrayList<String[]> rows=new ArrayList<>();try{Matcher m=Pattern.compile(pattern,Pattern.MULTILINE).matcher(new DeadlineText(text,System.nanoTime()+500000000));while(m.find()&&rows.size()<500){String[] row=new String[Math.min(m.groupCount(),20)+2];row[0]=Integer.toString(m.start());for(int i=0;i<row.length-1;i++)row[i+1]=m.group(i);rows.add(row);}}catch(StackOverflowError e){throw new IllegalArgumentException("正则回溯过深，请简化表达式");}return rows;}
}
