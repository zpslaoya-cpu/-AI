package cn.laoya.capture.pro;
import java.io.*;import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
public final class Model {
 public static final AtomicLong ids=new AtomicLong();
 public static volatile boolean running,requestBreak,responseBreak,stopBatch;
 public static volatile String state="未启动";
 public static volatile int maxMB=16,delayMs=0,rateKB=0,repeat=1,interval=1000;
 public static volatile File directory;
 public static final CopyOnWriteArrayList<Rule> rules=new CopyOnWriteArrayList<>();
 public static final ConcurrentHashMap<Long,Gate> gates=new ConcurrentHashMap<>();
 private static final LinkedList<Flow> flows=new LinkedList<>();
 public static class Message implements Serializable {
  private static final long serialVersionUID=1;
  public String line="";public ArrayList<String> headers=new ArrayList<>();public String file="";public long size;public boolean complete=true;
  public String header(String name){for(String h:headers){int i=h.indexOf(':');if(i>0&&h.substring(0,i).trim().equalsIgnoreCase(name))return h.substring(i+1).trim();}return "";}
  public void set(String name,String value){headers.removeIf(h->h.regionMatches(true,0,name+":",0,name.length()+1));if(value!=null&&!value.isEmpty())headers.add(name+": "+value);}
  public void bytes(byte[] b)throws IOException {File f=File.createTempFile("body-",".bin",directory);try(FileOutputStream o=new FileOutputStream(f)){o.write(b);}file=f.getAbsolutePath();size=b.length;complete=true;}
  public byte[] bytes(int max)throws IOException {if(file.isEmpty())return new byte[0];try(InputStream i=new FileInputStream(file);ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=i.read(b,0,Math.min(b.length,max-o.size())))>0){o.write(b,0,n);if(o.size()>=max)break;}return o.toByteArray();}}
  public Message copy(){Message m=new Message();m.line=line;m.headers=new ArrayList<>(headers);m.file=file;m.size=size;m.complete=complete;return m;}
 }
 public static class Flow implements Serializable {
  private static final long serialVersionUID=1;
  public long id=ids.incrementAndGet(),start=System.currentTimeMillis(),connectAt,headersAt,end,up,down;
  public String method="",url="",host="",status="处理中",error="",note="",tag="";public boolean tls,star,replayed;public int rate;
  public Message request=new Message(),response=new Message();public Message originalRequest,originalResponse;
  public int code(){try{return Integer.parseInt(response.line.split(" ",3)[1]);}catch(Exception e){return 0;}}
 }
 public static class Rule implements Serializable {
  private static final long serialVersionUID=1;
  public String id=UUID.randomUUID().toString(),name="规则",host="",path="",method="",side="response",action="replace",key="",value="",find="",replace="",body="{}",type="application/json; charset=utf-8";public int status=200,delay,rate;public boolean enabled=true,regex;
 }
 public static class Gate {
  public final long id;public final String side;public Message message;public boolean cancel,done;public final long deadline=System.currentTimeMillis()+120000;
  Gate(long id,String side,Message m){this.id=id;this.side=side;message=m;}
  public synchronized void release(Message m,boolean cancelled){message=m;cancel=cancelled;done=true;notifyAll();}
 }
 public static synchronized void add(Flow f){flows.addFirst(f);while(flows.size()>500)flows.removeLast();}
 public static synchronized List<Flow> snapshot(){return new ArrayList<>(flows);}
 public static synchronized Flow find(long id){for(Flow f:flows)if(f.id==id)return f;return null;}
 public static synchronized void clear(){flows.clear();}
 public static synchronized void restore(List<Flow> list){flows.clear();flows.addAll(list);long max=ids.get();for(Flow f:list)max=Math.max(max,f.id);ids.set(max);}
 public static void releaseAll(){for(Gate g:gates.values())g.release(g.message,true);gates.clear();}
}
